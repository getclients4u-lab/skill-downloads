# AEO, GEO, and SEO

SEO:
- search intent;
- topic clusters;
- internal links;
- metadata;
- refresh dates;
- schema recommendations.

AEO:
- concise answers;
- definitions;
- FAQ structures;
- comparisons;
- question clusters.

GEO:
- clear entities;
- consistent organization facts;
- source attribution;
- quotable, defensible claims;
- expert authority;
- knowledge relationships;
- AI citation monitoring.

Create one content graph rather than unrelated channel assets.
