# Brand Intelligence

Maintain six separate layers:

1. Linguistic voice: rhythm, sentence length, punctuation, vocabulary, point of view, hooks, CTAs.
2. Strategic voice: positioning, worldview, authority, proof preference, offers, differentiators.
3. Emotional signature: warmth, directness, authority, optimism, provocation, humor.
4. Platform expression: distinct patterns for LinkedIn, X, newsletters, blogs, video, and other channels.
5. Negative voice: clichés, prohibited phrases, disliked tones, rejected structures, restricted topics.
6. Drift monitoring: ON_VOICE, ACCEPTABLE_EXPERIMENT, VOICE_DRIFT, OFF_BRAND, or INSUFFICIENT_EVIDENCE.

Do not infer sensitive personal attributes from writing samples.
