# Campaigns and Funnel

Recommended buyer stages:

- UNAWARE
- PROBLEM_AWARE
- SOLUTION_AWARE
- VENDOR_AWARE
- DECISION_READY
- CUSTOMER
- ADVOCATE

A campaign connects a business objective to a core thesis, audiences, offer, content pillars, channels, time window, success metrics, and constraints.

Do not optimize a calendar only for publishing frequency. Every item must have a job in the campaign.
