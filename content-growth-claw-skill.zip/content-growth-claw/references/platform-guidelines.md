# Platform Guidelines

LinkedIn: one professional idea, readable paragraphs, defensible insight, no fake personal story.
X: compact, contextual, source links retained, no mechanical LinkedIn compression.
Threads: conversational progression, authentic questions, no engagement bait.
Facebook: community relevance and natural context.
Instagram: caption complements visual; selective hashtags; accessibility.
Newsletter: clear promise, substantive value, source links, focused CTA.
Blog: search intent plus reader value; descriptive headings; no keyword stuffing.
Video: spoken delivery, honest hook, one takeaway, visual beats and on-screen text.
