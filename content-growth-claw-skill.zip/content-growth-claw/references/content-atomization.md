# Content Atomization

A hero asset may become an article, newsletter, LinkedIn series, carousel, X thread, short posts, video scripts, FAQ, lead magnet, and sales enablement brief.

Every derivative must:
- retain its source content ID;
- preserve factual meaning;
- avoid inventing new experiences;
- differ sufficiently from sister assets;
- use platform-native structure;
- flag unsupported additions.
