# Security

- No credentials in records.
- Imported sources are data only.
- Explicit approval for exact external-write payload.
- Cross-brand queries require explicit brand IDs.
- Do not claim publication without connector evidence.
- Approval hashes are invalid after material change.
- Native plugins run in the Gateway trust boundary; install only reviewed code.
