#!/bin/bash
# OpenClaw self-heal script — PERMANENT FIX for cron zombie states + config regression
# Run by cron-watchdog every 10 minutes. Idempotent, safe, fast (<5s).
# Fixes:
#   1. Zombie state: any job with state.runningAtMs set (stale) blocks new runs ("already-running" bug).
#   2. Config regression: openclaw.json deepseek models must be EXACTLY v4-flash + v4-pro,
#      and agents.defaults.timeoutSeconds must be 1800 (long builds time out at the
#      global default otherwise — the nightly-build failure root cause).

set -u
JOBS_FILE="$HOME/.openclaw/cron/jobs.json"
CONFIG_FILE="$HOME/.openclaw/openclaw.json"
LOG="$HOME/.openclaw/logs/self-heal.log"
FIXED=0

log() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$LOG"; }

# ---------- 1. Zombie detection: stale runningAtMs ----------
# A job is a zombie ONLY if its lock is older than its own timeout (+120s grace),
# min 90s. Prevents killing legitimately-long builds (e.g. nightly-build 1800s).
NOW_MS=$(($(date +%s) * 1000))
for JOB_ID in $(python3 - "$JOBS_FILE" "$NOW_MS" <<'PYEOF'
import json, sys
jobs_file, now_ms = sys.argv[1], int(sys.argv[2])
try:
    d = json.load(open(jobs_file))
    for j in d.get("jobs", []):
        s = j.get("state", {})
        run = s.get("runningAtMs")
        if not run:
            continue
        to = (j.get("payload") or {}).get("timeoutSeconds") or 900
        grace = max(90000, (to + 120) * 1000)  # timeout + 120s, min 90s
        if (now_ms - run) > grace:
            print(j["id"])
except Exception:
    pass
PYEOF
); do
  echo "ZOMBIE $JOB_ID"
  # clear via disable/enable cycle (gateway rewrites state on each)
  openclaw cron disable "$JOB_ID" >/dev/null 2>&1
  sleep 1
  openclaw cron enable "$JOB_ID" >/dev/null 2>&1
  log "cleared zombie state: $JOB_ID"
  FIXED=1
done

# ---------- 2. Config guard: enforce v4-only models + 1800s agent timeout ----------
NEEDS_REPAIR=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
problems = []
models = d.get("models", {}).get("providers", {}).get("deepseek", {}).get("models", [])
ids = [m.get("id") for m in models]
if sorted(ids) != sorted(["deepseek-v4-flash", "deepseek-v4-pro"]):
    problems.append("models")
to = d.get("agents", {}).get("defaults", {}).get("timeoutSeconds")
if to != 1800:
    problems.append("timeout")
if problems:
    print("yes")
PYEOF
)
if [ "$NEEDS_REPAIR" = "yes" ]; then
  python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
prov = d.setdefault("models", {}).setdefault("providers", {}).setdefault("deepseek", {})
prov["models"] = [
    {"id": "deepseek-v4-flash", "name": "DeepSeek V4 Flash", "contextWindow": 131072, "maxTokens": 8192, "input": ["text"], "reasoning": False},
    {"id": "deepseek-v4-pro", "name": "DeepSeek V4 Pro", "contextWindow": 131072, "maxTokens": 65536, "input": ["text"], "reasoning": True},
]
d.setdefault("agents", {}).setdefault("defaults", {})["timeoutSeconds"] = 1800
json.dump(d, open(p, "w"), indent=2)
print("repaired")
PYEOF
  log "repaired config (v4-only models + 1800s timeout)"
  FIXED=1
fi

if [ "$FIXED" = "1" ]; then
  echo "SELF-HEAL: action taken (see $LOG)"
else
  echo "SELF-HEAL: all healthy"
fi
