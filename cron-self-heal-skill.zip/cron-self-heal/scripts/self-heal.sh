#!/bin/bash
# cron-self-heal — PERMANENT fix for OpenClaw cron zombie states + model config regression
# Idempotent, safe, fast (<5s). Designed to run from cron-watchdog every 10 minutes.
#
# Fixes:
#   1. Zombie state: any job with state.runningAtMs set (stale >90s) blocks new runs
#      with "already-running" — gateway bug where timed-out runs never clear the lock.
#   2. Model config regression: openclaw.json provider models must be EXACTLY the
#      expected set. Legacy/phantom model IDs get re-added by config rewrites and
#      cause agent-turn cron runs to hang → timeout → zombie cascade.
#
# CONFIGURE: edit EXPECTED_MODELS below to match the instance's provider + models.

set -u
# Resolve the real OpenClaw home dir (OPENCLAW_HOME may point to the parent dir)
if [ -d "${OPENCLAW_HOME:-}/.openclaw" ]; then
  OC_HOME="${OPENCLAW_HOME}/.openclaw"
elif [ -d "$HOME/.openclaw" ]; then
  OC_HOME="$HOME/.openclaw"
else
  OC_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
fi
JOBS_FILE="$OC_HOME/cron/jobs.json"
CONFIG_FILE="$OC_HOME/openclaw.json"
LOG="$OC_HOME/logs/self-heal.log"
mkdir -p "$(dirname "$LOG")" 2>/dev/null || true
FIXED=0
ZOMBIE_AGE_MS=90000   # 90s: longer than any healthy run should hold the lock idle

# EDIT THIS: provider key + exact model IDs this instance must use.
PROVIDER="deepseek"
EXPECTED_MODELS=("deepseek-v4-flash" "deepseek-v4-pro")

log() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$LOG"; }

# ---------- 1. Zombie detection: stale runningAtMs ----------
NOW_MS=$(($(date +%s) * 1000))
for JOB_ID in $(python3 - "$JOBS_FILE" "$NOW_MS" "$ZOMBIE_AGE_MS" <<'PYEOF'
import json, sys
jobs_file, now_ms, age = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
try:
    d = json.load(open(jobs_file))
    for j in d.get("jobs", []):
        s = j.get("state", {})
        run = s.get("runningAtMs")
        if run and (now_ms - run) > age:
            print(j["id"])
except Exception:
    pass
PYEOF
); do
  echo "ZOMBIE $JOB_ID"
  openclaw cron disable "$JOB_ID" >/dev/null 2>&1
  sleep 1
  openclaw cron enable "$JOB_ID" >/dev/null 2>&1
  log "cleared zombie state: $JOB_ID"
  FIXED=1
done

# ---------- 2. Model config guard ----------
NEEDS_REPAIR=$(python3 - "$CONFIG_FILE" "$PROVIDER" "${EXPECTED_MODELS[@]}" <<'PYEOF'
import json, sys
p, provider = sys.argv[1], sys.argv[2]
expected = sorted(sys.argv[3:])
try:
    d = json.load(open(p))
    models = d.get("models", {}).get("providers", {}).get(provider, {}).get("models", [])
    ids = sorted(m.get("id") for m in models)
    if ids != expected:
        print("yes")
except Exception:
    print("yes")
PYEOF
)
if [ "$NEEDS_REPAIR" = "yes" ]; then
  python3 - "$CONFIG_FILE" "$PROVIDER" "${EXPECTED_MODELS[@]}" <<'PYEOF'
import json, sys
p, provider = sys.argv[1], sys.argv[2]
ids = sys.argv[3:]
d = json.load(open(p))
prov = d.setdefault("models", {}).setdefault("providers", {}).setdefault(provider, {})
prov["models"] = [
    {"id": i, "name": i, "contextWindow": 131072, "maxTokens": 8192, "input": ["text"], "reasoning": False}
    for i in ids
]
json.dump(d, open(p, "w"), indent=2)
print("repaired")
PYEOF
  log "repaired model config -> ${EXPECTED_MODELS[*]}"
  FIXED=1
fi

if [ "$FIXED" = "1" ]; then
  echo "SELF-HEAL: action taken (see $LOG)"
else
  echo "SELF-HEAL: all healthy"
fi
