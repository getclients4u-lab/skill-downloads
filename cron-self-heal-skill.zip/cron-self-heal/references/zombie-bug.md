# OpenClaw Cron Zombie Bug — Root Cause Analysis

## The bug

OpenClaw stores cron definitions + runtime state in `~/.openclaw/cron/jobs.json`.
Each job carries `state.runningAtMs` — set when a run starts, cleared when it
finishes. **When a run times out or the process dies mid-run, the gateway never
clears `runningAtMs`.** The job is then permanently marked "running", and every
scheduled fire is skipped with "already-running". One failed run blocks all
future runs of that job.

Observed in OpenClaw 2026.4.2. No built-in config option auto-clears stale
locks (verified: no `zombie*`/`stale` settings in cron docs or config schema).

## Cascade pattern (how it escalates)

1. `openclaw.json` provider models array regresses (legacy/phantom IDs
   reappear after config rewrites or updates) — e.g. `deepseek-chat`/
   `deepseek-reasoner` re-added alongside or instead of the intended v4 models.
2. An agent-turn cron job configured with a valid model ID still runs, but
   other jobs referencing the phantom set hang → hit `timeoutSeconds` →
   `lastErrorReason: timeout`.
3. The timed-out run leaves `state.runningAtMs` set → zombie.
4. The watchdog job (if any) is itself a cron agent turn — it can suffer the
   same timeout/zombie, so the whole schedule freezes silently.

## Evidence signature

- `openclaw cron runs --id <job-id>` shows `"status": "error"`,
  `"error": "...timed out..."`, `"delivered": true`
- `jobs.json` shows `"runningAtMs": <stale epoch ms>` alongside
  `"lastRunStatus": "error"`, `"consecutiveErrors": N`
- `~/.openclaw/openclaw.json.clobbered.*` backup files prove periodic config
  rewrites (each rewrite = one `.clobbered` file) — the source of model
  regressions.

## The fix (two parts)

### Part 1 — zombie clearing (immediate unblock)

```bash
openclaw cron disable <job-id>   # forces state rewrite, drops the lock
openclaw cron enable <job-id>    # re-arms the schedule
```

Manual version of what `self-heal.sh` automates.

### Part 2 — prevention (permanent)

- `self-heal.sh` runs from the cron-watchdog every 10 minutes (was 30).
  Worst-case recovery drops from hours to ≤10 minutes.
- The config guard keeps provider models pinned to the exact intended set, so
  the timeout trigger never reappears.
- Keep the watchdog's own run simple (single script call) so it can't hang on
  multi-step reasoning and zombie itself.

## Key paths

| Path | Purpose |
|---|---|
| `~/.openclaw/cron/jobs.json` | cron definitions + `state.runningAtMs` |
| `~/.openclaw/openclaw.json` | provider/model config (hot-reloads on save) |
| `~/.openclaw/logs/self-heal.log` | self-heal action log |
| `~/.openclaw/openclaw.json.clobbered.*` | proof of config rewrites (regression source) |

## Lessons learned

- Verify `openclaw.json` model IDs exist for the provider BEFORE debugging
  timeouts — phantom models are the usual first domino.
- A manual `openclaw cron run <id>` can also time out mid-build; for long
  missions bump `timeoutSeconds` or split into phases.
- Empty `files:[]` Vercel deployments replace production with an empty deploy —
  unrelated but same "silent breakage" family; always redeploy from git.
