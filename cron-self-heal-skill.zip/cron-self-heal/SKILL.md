---
name: cron-self-heal
description: Fix and permanently prevent OpenClaw cron zombie states (stale state.runningAtMs blocking scheduled runs with "already-running") and model config regressions (phantom/legacy model IDs reappearing in openclaw.json and causing cron runs to hang and time out). Use when cron jobs stop firing, show lastStatus error/timeout, a job is stuck in a running state forever, or after any OpenClaw config rewrite or update that may have reverted models. Provides a self-heal script (self-heal.sh) and wiring instructions to run it from the cron-watchdog job every 10 minutes.
---

# cron-self-heal

Detect and permanently fix OpenClaw cron zombie states and model-config regressions.

## When to use

- A cron job has `state.runningAtMs` set (stale) and never fires again ("already-running")
- `openclaw cron list` shows `lastStatus: error` / `lastErrorReason: timeout` repeatedly
- Agent-turn cron jobs hang then time out, cascading into blocked schedules
- After config rewrites, `openclaw.json` models reverted to legacy/phantom IDs

## Quick start (3 steps)

### 1. Install the script

Copy `scripts/self-heal.sh` to the instance workspace and make it executable:

```bash
cp scripts/self-heal.sh ~/.openclaw/workspace/self-heal.sh
chmod +x ~/.openclaw/workspace/self-heal.sh
```

### 2. Configure it for this instance

Edit the two variables at the top of `self-heal.sh`:

```bash
PROVIDER="deepseek"                          # provider key in openclaw.json
EXPECTED_MODELS=("deepseek-v4-flash" "deepseek-v4-pro")  # EXACT model IDs
```

Set `EXPECTED_MODELS` to the exact models the instance must use. The guard
rewrites the models array to precisely this set if anything else appears.

### 3. Wire it into the cron-watchdog

Update the watchdog job (or create one) to run the script every 10 minutes:

```bash
openclaw cron edit <watchdog-id> \
  --cron "*/10 * * * *" \
  --tz "America/New_York" \
  --message "Run FIRST: bash /var/openclaw_users/isa/.openclaw/workspace/self-heal.sh (clears zombie runningAtMs via disable/enable, repairs model config). If it reports action taken, summarize. Otherwise reply NO_REPLY."
```

If no watchdog job exists, create one:

```bash
openclaw cron add --name cron-watchdog --cron "*/10 * * * *" --tz "America/New_York" \
  --message "Run FIRST: bash /var/openclaw_users/isa/.openclaw/workspace/self-heal.sh ..."
```

## How it works

**Zombie clearing** — reads `~/.openclaw/cron/jobs.json`; any job whose
`state.runningAtMs` is older than 90s is a zombie (timed-out run never released
the lock). Cleared via `openclaw cron disable <id>` then `enable <id>`, which
forces the gateway to rewrite the state and drop the stale lock.

**Config guard** — reads `~/.openclaw/openclaw.json`; if the provider's models
array isn't exactly `EXPECTED_MODELS`, rewrites it (gateway hot-reloads config,
no restart needed). Prevents phantom model IDs from hanging agent runs.

All actions are logged to `~/.openclaw/logs/self-heal.log`.

## Verification (fault injection)

Test both fixes without waiting for a real failure:

```bash
# Zombie test: inject a stale lock on a job
python3 -c "
import json, time
p = '$HOME/.openclaw/cron/jobs.json'
d = json.load(open(p))
d['jobs'][0]['state']['runningAtMs'] = int(time.time()*1000) - 300000
json.dump(d, open(p, 'w'), indent=2)
"
bash self-heal.sh   # expect: ZOMBIE <id> / SELF-HEAL: action taken
# Config test: append a phantom model
python3 -c "
import json
p = '$HOME/.openclaw/openclaw.json'
d = json.load(open(p))
d['models']['providers']['deepseek']['models'].append({'id':'deepseek-chat','name':'x'})
json.dump(d, open(p, 'w'), indent=2)
"
bash self-heal.sh   # expect: repaired / SELF-HEAL: action taken
```

See `references/zombie-bug.md` for the full root-cause analysis.
