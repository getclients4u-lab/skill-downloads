# Memory Bank — GC Workflow Setup
*Generated: 2026-05-11*

## SMTP Config (use this for all 3 emails)
- From Name: Chad
- From Email: chad@mail.nicelysupport.com
- Reply To: chad@mail.nicelysupport.com
- Domain ID: 668854f8cfe6ae024a58f18d
- Integration ID: 628e75aa84279536ff4eb41a
- Account ID: 668854e8cfe6ae024a58ef72

## Tag to Create First
- Name: `skill-memory-bank`
- Group: Skills
- Description: Skill: Memory Bank

## Workflow Setup in GC Dashboard
1. Workflows → New Workflow
2. Group: **Skill Workflows**
3. Name: `Memory Bank — Skill Nurture`
4. Trigger: Tag applied → `skill-memory-bank`
5. Add 3 email steps with timers below

---

## Email 1 — Send Immediately (Day 0)

**Subject:** Your Memory Bank skill is ready to install...
**Preview:** Your AI is about to get a whole lot smarter.

**HTML Body:**
```html
<p>Hey {firstName},</p>
<p>&nbsp;</p>
<p>Your Memory Bank skill is ready.</p>
<p>&nbsp;</p>
<p>Click here to download it now → <a href="https://www.dropbox.com/scl/fi/vq1rjpk0w74swyl1k1a4o/memory-bank.zip?rlkey=35lzw9hc9ram9jq40ln1q5bvw&dl=1">Click here to download Memory Bank</a></p>
<p>&nbsp;</p>
<p>Here's what just changed for you:</p>
<p>&nbsp;</p>
<p>Every workshop, training, transcript, or piece of research you've ever wanted your AI to remember? Now it can.</p>
<p>&nbsp;</p>
<p>Drop it in. Ask questions. Get answers pulled from YOUR content — not generic internet stuff.</p>
<p>&nbsp;</p>
<p><a href="https://www.dropbox.com/scl/fi/vq1rjpk0w74swyl1k1a4o/memory-bank.zip?rlkey=35lzw9hc9ram9jq40ln1q5bvw&dl=1">Click here to install your free Memory Bank skill</a></p>
<p>&nbsp;</p>
<p>Talk soon,<br>Chad</p>
<p>&nbsp;</p>
<p>P.S. Once it's installed, try feeding it your last training call. You'll be amazed what it can do. <a href="https://www.dropbox.com/scl/fi/vq1rjpk0w74swyl1k1a4o/memory-bank.zip?rlkey=35lzw9hc9ram9jq40ln1q5bvw&dl=1">Click here to get started</a></p>
```

---

## Timer: Wait 2 Days

---

## Email 2 — Day 2

**Subject:** Did you get your Memory Bank installed?
**Preview:** Takes 2 minutes. Changes everything.

**HTML Body:**
```html
<p>Hey {firstName},</p>
<p>&nbsp;</p>
<p>Just checking in — did you get your Memory Bank skill installed?</p>
<p>&nbsp;</p>
<p>If not, here's your download link again:</p>
<p>&nbsp;</p>
<p><a href="https://www.dropbox.com/scl/fi/vq1rjpk0w74swyl1k1a4o/memory-bank.zip?rlkey=35lzw9hc9ram9jq40ln1q5bvw&dl=1">Click here to download Memory Bank</a></p>
<p>&nbsp;</p>
<p>Once it's in, here's the first thing to try:</p>
<p>&nbsp;</p>
<p>Grab the transcript from your last training call or workshop. Paste it in. Then ask your AI a question about it.</p>
<p>&nbsp;</p>
<p>Watch it answer like it was in the room.</p>
<p>&nbsp;</p>
<p>That's the power of Memory Bank. Your AI stops being generic and starts being YOUR expert.</p>
<p>&nbsp;</p>
<p><a href="https://openclaw-memory-bank.vercel.app">Click here to get back to your download page</a></p>
<p>&nbsp;</p>
<p>Chad</p>
<p>&nbsp;</p>
<p>P.S. Tomorrow I'm going to show you something else you get access to with OpenClaw. You're going to want to see this.</p>
```

---

## Timer: Wait 3 More Days (5 days total)

---

## Email 3 — Day 5

**Subject:** You're missing this (it comes with your skill)
**Preview:** Claw Launcher. Members Area. Summit Replays. All yours.

**HTML Body:**
```html
<p>Hey {firstName},</p>
<p>&nbsp;</p>
<p>When you grabbed the Memory Bank skill, you didn't just get a skill.</p>
<p>&nbsp;</p>
<p>You got the full OpenClaw ecosystem.</p>
<p>&nbsp;</p>
<p>Here's everything that's waiting for you:</p>
<p>&nbsp;</p>
<p>🚀 <strong>Claw Launcher</strong> — the app that runs all your OpenClaw skills. Free. Powerful. Already yours.</p>
<p>&nbsp;</p>
<p>🎓 <strong>The Members Area</strong> — step-by-step training on using Memory Bank, building workflows, and getting results. All included.</p>
<p>&nbsp;</p>
<p>🎤 <strong>Summit Replays</strong> — real OpenClaw users showing exactly how they use skills like Memory Bank in their businesses. Watch them. Steal their ideas.</p>
<p>&nbsp;</p>
<p><a href="https://openclaw-memory-bank.vercel.app">Click here to access everything you get</a></p>
<p>&nbsp;</p>
<p>The next live OpenClaw Summit is coming up fast. You're already registered.</p>
<p>&nbsp;</p>
<p>Don't miss it.</p>
<p>&nbsp;</p>
<p><a href="https://openclaw-memory-bank.vercel.app">Click here to see what's included</a></p>
<p>&nbsp;</p>
<p>Chad</p>
<p>&nbsp;</p>
<p>P.S. The Summit fills up fast. Make sure you've logged into Claw Launcher so your seat is locked in. <a href="https://openclaw-memory-bank.vercel.app">Click here</a></p>
```

---

## Download Links Used
- Skill zip: https://www.dropbox.com/scl/fi/vq1rjpk0w74swyl1k1a4o/memory-bank.zip?rlkey=35lzw9hc9ram9jq40ln1q5bvw&dl=1
- Skill page: https://openclaw-memory-bank.vercel.app
