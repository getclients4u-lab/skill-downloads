---
name: Skill Package
slug: skill-package
author: Pacino
description: >
  Full skill launch system. Takes any installed OpenClaw skill, zips it, uploads to Dropbox,
  builds a themed landing page, creates a GC tag, and sets up a 3-email nurture workflow — all in one command.
version: 2.0.0
trigger: /skill package
emoji: 📦
---

# Skill Package

**Trigger:** `/skill package`

**Purpose:** Turn any OpenClaw skill into a complete giveaway funnel — skill zip in GitHub storage (Dropbox replacement), branded landing page on Vercel, GC tag, and 3-email nurture sequence. All automated.

> ⚠️ <b>THIS INSTALL USES GITHUB FOR ZIP STORAGE, NOT DROPBOX.</b>
> See `references/github-storage.md` for the GitHub upload method (Step 2).
> Repo: `getclients4u-lab/skill-downloads` · Token: `config/github-token.json`
> This supersedes the original Dropbox instructions below.

---

## Trigger Response

When `/skill package` is typed, ask exactly:

> "📦 Let's build your skill package! I need one thing:
> 1. **Skill name** — what's the exact name of the skill?"

Tag name is **auto-generated**: always `skill-[skill-slug]` (e.g., `skill-memory-bank`). Never ask Chad for the tag name.

Wait for the skill name, then execute all steps below automatically.

---

## Step 1 — Credential Safety Check + Zip

1. Locate skill folder: `~/.openclaw/workspace/skills/[skill-slug]/`
2. Run credential scan before zipping:
   ```powershell
   Select-String -Path "C:\Users\Administrator\.openclaw\workspace\skills\[skill-slug]\*" -Pattern "[a-f0-9]{64}|sk_|pk_|vcp_|Bearer|API.?KEY|apiKey"
   ```
   ⚠️ Note: `-Recurse` is NOT supported on Select-String in this environment — omit it.
3. If any credentials found → replace with `YOUR_API_KEY_HERE` placeholder, then proceed
4. Zip the folder:
   ```powershell
   Compress-Archive -Path "C:\Users\Administrator\.openclaw\workspace\skills\[skill-slug]" -DestinationPath "C:\Users\Administrator\.openclaw\workspace\[skill-slug].zip" -Force
   ```

---

## Step 2 — Upload to Dropbox /Skills Folder

- Token: `credentials/credentials-dropbox.txt`
- ⚠️ Test token first — if expired, tell Chad: "Dropbox token is expired. Please go to dropbox.com/developers/apps, click your app, and Generate a new access token."
- Upload via curl (NOT Invoke-RestMethod — avoids encoding issues):
  ```powershell
  $token = Get-Content "C:\Users\Administrator\.openclaw\workspace\credentials\credentials-dropbox.txt" | Where-Object { $_ -match "^sl\." } | Select-Object -First 1
  $zipPath = "C:\Users\Administrator\.openclaw\workspace\[skill-slug].zip"
  $apiArg = '{"path":"/Skills/[skill-name].zip","mode":"overwrite","autorename":false}'
  curl.exe -s -X POST "https://content.dropboxapi.com/2/files/upload" `
    -H "Authorization: Bearer $token" `
    -H "Dropbox-API-Arg: $apiArg" `
    -H "Content-Type: application/octet-stream" `
    --data-binary "@$zipPath"

  # Get share link
  [System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\db-share.json", '{"path":"/Skills/[skill-name].zip","settings":{"requested_visibility":"public"}}')
  $share = curl.exe -s -X POST "https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings" `
    -H "Authorization: Bearer $token" `
    -H "Content-Type: application/json" `
    --data-binary "@C:\Users\Administrator\.openclaw\workspace\db-share.json" | ConvertFrom-Json
  $downloadUrl = $share.url -replace "dl=0","dl=1"
  ```
- Save `$downloadUrl` — used in landing page CTA buttons and email links

---

## Step 3 — Build & Deploy Skill Landing Page

### Pick Theme Based on Skill Type
| Skill Type | Theme | Colors |
|-----------|-------|--------|
| Lead gen / prospecting / sales | **Prospector** | Gold `#ffb400` + Orange `#ff7a00` on Deep Blue `#07142d` |
| Money / revenue / income | **Emerald** | Green `#22c55e` + Teal `#06b6d4` on Dark Green `#0a1f0a` |
| Outreach / cold email / follow-up | **Crimson** | Red `#ef4444` + Orange `#f97316` on Dark Red `#1a0a0a` |
| AI / automation / bots | **Royal** | Purple `#a855f7` + Blue `#3b82f6` on Deep Purple `#0f0a1f` |
| Content / social media / video | **Sunrise** | Yellow `#fbbf24` + Pink `#f472b6` on Dark Navy `#0a0f1f` |
| Data / analytics / reporting | **Steel** | Blue `#60a5fa` + Slate `#94a3b8` on Charcoal `#0f1117` |
| Local / community / newsletter | **Forest** | Green `#4ade80` + Gold `#facc15` on Dark Forest `#0a1a0f` |
| Launch / urgency / deadline | **Inferno** | Orange `#fb923c` + Red `#f43f5e` on Near Black `#12080a` |

### Page Build Process
⚠️ ABSOLUTE RULE: NEVER recreate the page from scratch. ALWAYS clone the master template.

1. Copy the ENTIRE master template folder:
   ```powershell
   Copy-Item -Path "C:\Users\Administrator\.openclaw\workspace\openclaw-skill-page" -Destination "C:\Users\Administrator\.openclaw\workspace\openclaw-[skill-slug]" -Recurse
   ```
2. Open `C:\Users\Administrator\.openclaw\workspace\openclaw-[skill-slug]\public\index.html`
3. Use `edit` tool to swap ONLY these elements (do NOT rewrite the file):
   - **Title + meta:** skill name + tagline
   - **CSS `--c1`, `--c2`, `--c3`, `--bg`, `--bg2`:** swap to chosen theme colors
   - **Aurora blob colors:** match theme
   - **Eyebrow badge text:** skill-specific
   - **Headline:** transformation hook for this skill
   - **Subheadline/sub paragraph:** what the skill does
   - **3 bullets:** benefit-driven copy for this skill
   - **Bottom band h2 + p:** pain/urgency copy for this skill
   - **2 feature boxes:** key differentiators for this skill
   - **Access card text:** updated for this skill
   - **Popup h2 + p:** updated for this skill
   - **Perk 1:** skill name + what it does (perks 2-4 stay the same every time)
   - **ALL CTA button links:** → `$downloadUrl` (Dropbox)
   - Everything else (animations, layout, structure, WOW factor) stays EXACTLY as cloned

4. Remove `.vercel` folder from cloned directory BEFORE deploying (otherwise it deploys to the master project):
   ```powershell
   Remove-Item -Recurse -Force "C:\Users\Administrator\.openclaw\workspace\openclaw-[skill-slug]\.vercel" -ErrorAction SilentlyContinue
   ```

5. Deploy to Vercel with `--name` flag to create a NEW project (not overwrite master):
   ```powershell
   cd "C:\Users\Administrator\.openclaw\workspace\openclaw-[skill-slug]"
   npx vercel --prod --yes --name "openclaw-[skill-slug]" --token "YOUR_VERCEL_TOKEN"
   ```
6. Save the deployed URL as `$pageUrl`

---

## ⚠️ LANDING PAGE API INTEGRATION RULES (2026-05-11 - ABSOLUTE)

### The CORS Problem
**NEVER call GC (or any external API) directly from browser JavaScript on the landing page.**
- The browser's CORS policy **silently blocks** these calls
- The form appears to submit successfully but NOTHING goes into GC
- There is NO error shown to the user — it just fails invisibly

### The Fix — Always Use a Vercel Serverless Route
When building/deploying a landing page with GC integration:

**1. Create `api/subscribe.js` in the project root (NOT inside `public/`):**
```javascript
const GC_API_KEY = '[key]';
const GC_BASE = 'https://api.globalcontrol.io/api/ai';
const TAG_ID = '[tag-id]';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { firstName, lastName, email } = req.body || {};
  const headers = { 'X-API-KEY': GC_API_KEY, 'Content-Type': 'application/json' };

  // 1. Create contact
  await fetch(`${GC_BASE}/contacts`, {
    method: 'POST', headers,
    body: JSON.stringify({ firstName, lastName, email })
  });

  // 2. Fire tag
  await fetch(`${GC_BASE}/tags/fire-tag/${TAG_ID}`, {
    method: 'POST', headers,
    body: JSON.stringify({ email, firstName, lastName })
  });

  return res.status(200).json({ success: true });
}
```

**2. Update `vercel.json` to use `rewrites` (NOT `builds`):**
```json
{
  "version": 2,
  "rewrites": [
    { "source": "/api/:path*", "destination": "/api/:path*" },
    { "source": "/(.*)", "destination": "/public/$1" }
  ]
}
```
⚠️ Using `builds` instead of `rewrites` breaks serverless routing — the API route returns 404.

**3. In the frontend HTML — call `/api/subscribe` (NOT the GC URL directly):**
```javascript
await fetch('/api/subscribe', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ firstName, lastName, email })
});
```

**Benefits:**
- ✅ No CORS issues (same domain call)
- ✅ API key is hidden server-side (never exposed in browser)
- ✅ GC actually receives contacts and tags fire correctly

### 🚨 GC + Redirect Pattern — THE ONLY WAY THAT WORKS (2026-05-11)

**The problem with fire-and-forget:**
```javascript
// ❌ NEVER DO THIS — browser cancels the fetch when it navigates away
fetch('/api/subscribe', { ... }); // fires but gets cancelled
window.location.href = '/thank-you.html'; // redirect kills the request
```

**The problem with full await:**
```javascript
// ⚠️ Works but feels slow if GC takes 2-3 seconds
await fetch('/api/subscribe', { ... });
window.location.href = '/thank-you.html';
```

**✅ THE CORRECT PATTERN — Race GC vs timeout:**
```javascript
// GC call races against 1.5s timeout — redirect whichever wins first
await Promise.race([
  fetch('/api/subscribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ firstName, lastName, email })
  }),
  new Promise(resolve => setTimeout(resolve, 1500))
]).catch(() => {});

window.location.href = '/thank-you.html';
```

**Why this works:**
- If GC responds in <1.5s (usually does) → redirects immediately after GC confirms
- If GC is slow → redirects at 1.5s max regardless
- Lead always gets into GC, UX always feels fast
- Button text during wait: `⚡ One sec...` (not "Getting Your Access Ready..." — too slow-sounding)

**Always use this pattern for any form → GC → redirect flow.**

### Thank-You Page (ALWAYS build one — matches the main page theme)

Every skill landing page MUST have a `/thank-you` page. Build it alongside `index.html`.

**What it does:**
- Auto-triggers the download on page load (800ms delay)
- Shows a manual download button as fallback
- 3-step "what to do next" cards (Install → Run → Result)
- Inbox note telling them to check email
- Same color theme as the main page (`--gold`, `--orange`, background gradient)

**Redirect flow:** After popup form submits → `window.location.href = '/thank-you'` (not setTimeout closePopup)

**vercel.json must include the route:**
```json
{ "source": "/thank-you", "destination": "/public/thank-you.html" }
```

**thank-you.html structure:**
1. Animated ✅ check ring (gradient, pulsing glow)
2. "You're officially in!" eyebrow badge
3. Headline: "Your download is starting now."
4. Download card with manual fallback button
5. 3-step instruction cards
6. Inbox note (check email for access)
7. Footer

**Skill-specific customization (swap per skill):**
- Page `<title>` and meta description
- Headline sub-copy (mention the skill name)
- Step 2 instruction: the exact command to run the skill
- Step 3: the result/outcome of the skill
- DROPBOX_URL constant

### Download Buttons — Never Use `<a href>` for File Downloads
Using `<a href="dropbox-url">` causes page navigation/refresh instead of downloading.

**Always use this JS pattern:**
```javascript
function downloadSkill() {
  const link = document.createElement('a');
  link.href = DROPBOX_URL;
  link.download = 'skill.zip';
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
```
And in HTML: `<button class="btn btn-primary" onclick="downloadSkill()">Get the Free Skill 🎉</button>`

### Button Text Color
Gradient buttons need `color: #ffffff !important` — without `!important`, inherited link styles override and text becomes invisible.

---

## Step 4 — Create GC Tag

- API key: `credentials/gc-api-key.txt`
- Tag name: always `skill-[skill-slug]` (auto-generated, never ask Chad)

⚠️ CRITICAL: ALL GC API writes must use `[System.IO.File]::WriteAllText()` for JSON files. NEVER use `Out-File` or `ConvertTo-Json | Set-Content` — these add BOM characters that cause "Invalid Json Format" errors.

```powershell
$gcKey = Get-Content "C:\Users\Administrator\.openclaw\workspace\credentials\gc-api-key.txt" | Where-Object { $_ -match "^[a-f0-9]{64}$" } | Select-Object -First 1

# Get or create "Skills" tag group
$groups = curl.exe -s "https://api.globalcontrol.io/api/ai/tag-groups" -H "X-API-KEY: $gcKey" | ConvertFrom-Json
$skillsGroup = $groups.data | Where-Object { $_.name -eq "Skills" } | Select-Object -First 1
if (-not $skillsGroup) {
    [System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\gc-body.json", '{"name":"Skills","description":"OpenClaw skill tags"}')
    $result = curl.exe -s -X POST "https://api.globalcontrol.io/api/ai/tag-groups" -H "X-API-KEY: $gcKey" -H "Content-Type: application/json" --data-binary "@C:\Users\Administrator\.openclaw\workspace\gc-body.json" | ConvertFrom-Json
    $groupId = $result.data._id
} else {
    $groupId = $skillsGroup._id
}

# Create tag
[System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\gc-body.json", "{`"name`":`"skill-[skill-slug]`",`"description`":`"Skill: [Skill Name]`",`"groupId`":`"$groupId`",`"isHot`":false}")
$tag = curl.exe -s -X POST "https://api.globalcontrol.io/api/ai/tags" -H "X-API-KEY: $gcKey" -H "Content-Type: application/json" --data-binary "@C:\Users\Administrator\.openclaw\workspace\gc-body.json" | ConvertFrom-Json
$tagId = $tag.data._id
```

---

## Step 5 — Create GC Workflow (3 emails over 5 days)

### ⚠️ CRITICAL GC Workflow API Rules (learned the hard way)

1. **Flow type is `SEND_EMAIL`** — NOT `EMAIL`. Using `EMAIL` creates broken flows.
2. **Email fields are flat in `data`**: `body`, `subject`, `preview`, `from_name`, `from_email`, `reply_to`. Do NOT use a nested `smtpConfig` object inside the email data.
3. **PUT `/workflows/{id}` APPENDS flows** — it does NOT replace them. If you need to fix flows, DELETE the workflow and create a new one.
4. **DELETE `/workflows/{id}/flows/{flowId}` returns 401** — individual flow deletion is not supported via API. Always delete the whole workflow and rebuild.
5. **Sending domain must be set at the WORKFLOW level** (separate PUT call), not just in email bodies.
6. **Build flows using PowerShell objects + `ConvertTo-Json -Depth 10 -Compress`** — this handles all escaping automatically. Avoid manual JSON string building with backtick escaping.

### Workflow Creation Pattern

```powershell
$wfGroupId = "6a022aaf7a98f2fec5ba01f9"  # "Open Claw Skills" group

# Step 1: Create workflow
[System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\gc-body.json", "{`"name`":`"[Skill Name] - Skill Nurture`",`"workflowGroupId`":`"$wfGroupId`"}")
$wf = curl.exe -s -X POST "https://api.globalcontrol.io/api/ai/workflows" -H "X-API-KEY: $gcKey" -H "Content-Type: application/json" --data-binary "@C:\Users\Administrator\.openclaw\workspace\gc-body.json" | ConvertFrom-Json
$wfId = $wf.data._id

# Step 2: Set sending domain at workflow level (REQUIRED — separate call)
[System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\gc-body.json", '{"domainId":"6688551acfe6ae024a58f9f6","smtpConfig":{"domain":"mg.chadnicely.com","accountId":"668854e8cfe6ae024a58ef72","integrationId":"628e75aa84279536ff4eb41a"}}')
curl.exe -s -X PUT "https://api.globalcontrol.io/api/ai/workflows/$wfId" -H "X-API-KEY: $gcKey" -H "Content-Type: application/json" --data-binary "@C:\Users\Administrator\.openclaw\workspace\gc-body.json" | Out-Null

# Step 3: Build flows with PowerShell objects (handles escaping)
$flows = @(
    @{
        type="SEND_EMAIL"; index=0; label="Email 1 - Skill Ready"
        data=@{
            subject="[subject line]"
            preview="[preview text]"
            body=$b1   # HTML string variable
            from_name="Chad Nicely"
            from_email="chad@mg.chadnicely.com"
            reply_to="support@nicelysupport.com"
        }
    },
    @{ type="TIMER"; index=1; label="Wait 2 Days"; data=@{ days=2; hours=0; minutes=0 } },
    @{
        type="SEND_EMAIL"; index=2; label="Email 2 - Check In"
        data=@{
            subject="[subject line]"
            preview="[preview text]"
            body=$b2
            from_name="Chad Nicely"
            from_email="chad@mg.chadnicely.com"
            reply_to="support@nicelysupport.com"
        }
    },
    @{ type="TIMER"; index=3; label="Wait 3 Days"; data=@{ days=3; hours=0; minutes=0 } },
    @{
        type="SEND_EMAIL"; index=4; label="Email 3 - Big Picture"
        data=@{
            subject="[subject line]"
            preview="[preview text]"
            body=$b3
            from_name="Chad Nicely"
            from_email="chad@mg.chadnicely.com"
            reply_to="support@nicelysupport.com"
        }
    }
)

$payload = @{ flows = $flows } | ConvertTo-Json -Depth 10 -Compress
[System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\gc-flows.json", $payload)
curl.exe -s -X PUT "https://api.globalcontrol.io/api/ai/workflows/$wfId" -H "X-API-KEY: $gcKey" -H "Content-Type: application/json" --data-binary "@C:\Users\Administrator\.openclaw\workspace\gc-flows.json" | Out-Null

# Step 4: Link tag to workflow
[System.IO.File]::WriteAllText("C:\Users\Administrator\.openclaw\workspace\gc-body.json", "{`"workflows`":[`"$wfId`"]}")
curl.exe -s -X PUT "https://api.globalcontrol.io/api/ai/tags/$tagId" -H "X-API-KEY: $gcKey" -H "Content-Type: application/json" --data-binary "@C:\Users\Administrator\.openclaw\workspace\gc-body.json" | Out-Null
```

### Email Copy Standards (using Inbox Copywriter skill)

**Category:** Curiosity (Email 1) → Relationship (Email 2) → Authority/Big Opportunity (Email 3)
**Style:** Daily Email — conversational, punchy, human

**Formatting rules:**
- Font size: `18px`, line-height: `1.6` on every `<p>` tag: `<p style="font-size:18px;line-height:1.6;">`
- **NO spacer paragraphs** (`<p>&nbsp;</p>`) between every line — this makes emails look bloated
- Use blank lines ONLY for dramatic effect/breath (max 1-2 per email)
- Short paragraphs: 1-3 sentences max
- Merge tag: `{{firstName}}` (double curly braces)
- Links: always "Click here to [action]" format — NEVER bare URLs
- Link in first 3-4 sentences (mandatory)
- P.S. with link on every email (mandatory)
- No emojis in email body — GC renders them as garbage characters

**Email 1 — Day 0 (fires immediately)**
- Hook: skill just landed / here's what it does
- Link: `$downloadUrl` (Dropbox download)
- Angle: explain the "before vs after" in 2-3 sentences
- Close: simple, direct, 1 action

**Email 2 — Day 2**
- Hook: quick question / did you install it?
- Link: `$downloadUrl` early, `$pageUrl` in P.S.
- Angle: give them one concrete thing to try
- Tone: friendly check-in, no pressure

**Email 3 — Day 5**
- Hook: "most people think they got a free skill..."
- Link: `$pageUrl` early
- Angle: everything they unlocked — Claw Launcher, Members Area, Summit
- Close: "You didn't just download a skill. You joined something."

### SMTP Config (GC verified working)
| Field | Value |
|-------|-------|
| domainId | `6688551acfe6ae024a58f9f6` |
| domain | `mg.chadnicely.com` |
| accountId | `668854e8cfe6ae024a58ef72` |
| integrationId | `628e75aa84279536ff4eb41a` |
| from_name | `Chad Nicely` |
| from_email | `chad@mg.chadnicely.com` |
| reply_to | `support@nicelysupport.com` |

### ⚠️ One Manual Step (API limitation)
GC API cannot set the Campaign Trigger (firingTags). Always tell Chad:
> "One manual step: GC Dashboard → Workflows → [workflow name] → Campaign Trigger → select `skill-[slug]` → Activate"

---

## Step 6 — Report Back

```
✅ SKILL PACKAGE COMPLETE: [Skill Name]

📦 Skill zip → Dropbox /Skills/[skill-name].zip
   Download: [dropbox url]

🌐 Skill page → [page url]
   Theme: [theme name]

🏷️ GC Tag → skill-[slug] (Skills group)
   Tag ID: [id]

⚡ GC Workflow → "[Skill Name] - Skill Nurture"
   Email 1 → Wait 2 days → Email 2 → Wait 3 days → Email 3
   Domain: mg.chadnicely.com ✅
   Tag linked ✅

⚠️ Manual step: GC Dashboard → Workflow → Campaign Trigger → select skill-[slug] → Activate

Ready to promote! 🚀
```

---

## Key Credentials (Quick Reference)
- Vercel token: `credentials/credentials-vercel.txt`
- GC API key: `credentials/gc-api-key.txt`
- Dropbox token: `credentials/credentials-dropbox.txt` (⚠️ expires — test first)
- GitHub token: `credentials/credentials-github.txt`

## GC IDs (Quick Reference)
- Skills tag group: `6a022e597a98f2fec5bb5584`
- Open Claw Skills workflow group: `6a022aaf7a98f2fec5ba01f9`

## Master Template Location
`C:\Users\Administrator\.openclaw\workspace\openclaw-skill-page\public\index.html`
Live: https://openclaw-skill-page.vercel.app
