# GitHub Storage (Dropbox Replacement) — Skill Package

Use GitHub instead of Dropbox to host the skill zip. Benefits: no expiring tokens, versioned, free unlimited bandwidth, direct download URLs.

## Setup

- GitHub account: `getclients4u-lab` (this workspace's owner)
- Repo pattern: `skill-downloads` — a public repo holding all skill zips
- Auth: `config/github-token.json` (token for getclients4u-lab)

## Step 2 (GitHub version) — Upload skill zip to GitHub

Instead of Dropbox, commit the zip to a public GitHub repo and use the raw download URL.

### 1. Ensure the `skill-downloads` repo exists (create once)

```bash
TOKEN=$(python3 -c "import json; print(json.load(open('config/github-token.json'))['token'])")
curl -s -X POST https://api.github.com/user/repos \
  -H "Authorization: token $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"skill-downloads","description":"Public OpenClaw skill zips","auto_init":true}'
```

### 2. Push the zip to the repo

```bash
cd /var/openclaw_users/isa/.openclaw/workspace
git clone https://github.com/getclients4u-lab/skill-downloads.git /tmp/skill-downloads 2>/dev/null || (cd /tmp/skill-downloads && git pull)
cp skills/[slug].zip /tmp/skill-downloads/[slug].zip
cd /tmp/skill-downloads
git add [slug].zip
git commit -m "Add [skill-name] skill zip"
git push
```

### 3. Direct download URL

```
https://github.com/getclients4u-lab/skill-downloads/raw/main/[slug].zip
```

Save as `$downloadUrl` — used in landing page CTA buttons and email links.

## Notes

- GitHub raw URLs support direct download via JS `link.download` (no CORS issue).
- Use the `/raw/main/` URL in browser links and emails.
- Test the URL returns 200 before deploying the page.
