# Sendiio Client — Full Command Reference

`sendiio_client.py` is a complete wrapper for the Sendiio v1 API
(https://sendiio.com/pages/view/sendiio-api). Credentials are read from
`workspace/credentials/sendiio-key.txt` (token) and `sendiio-secret.txt` (secret).
Both were validated against the live API — account `user_id 12488`.

Auth: every request sends `token` and `secret` headers. The only public
(unauthenticated) endpoints are `subscribe`, `unsubscribe`, and `auth/check`.

## Quick Start

```bash
# Verify credentials
python3 scripts/sendiio_client.py check

# See your email lists (currently: none until you create one in the dashboard)
python3 scripts/sendiio_client.py lists
```

## Commands

### check
Validate token+secret against the live API.
```bash
python3 scripts/sendiio_client.py check
# OK — account user_id 12488
```

### lists
List all email lists (id, name, sender).
```bash
python3 scripts/sendiio_client.py lists
```

### subscribe  [public]
Add a lead to a list. Extra fields (first, last, tag) are auto-attached to the contact.
This is the endpoint your opt-in forms should call.
```bash
python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email lead@example.com --first Jane --tag int-product-x
```
Equivalent raw call:
```
POST https://sendiio.com/api/v1/lists/subscribe/json
  email_list_id=<encrypted_id>&email=<email>&first_name=<name>&tag=<tag>
```
No auth headers required for this endpoint.

### unsubscribe  [public]
Remove a lead from a list.
```bash
python3 scripts/sendiio_client.py unsubscribe --list-id [encrypted_id] --email lead@example.com
```

### list-get
Get list details by encrypted id (sender name, mail_from, created dates).
```bash
python3 scripts/sendiio_client.py list-get --id [encrypted_id]
```

### list-fields
Get the custom fields defined on a list.
```bash
python3 scripts/sendiio_client.py list-fields --id [encrypted_id]
```

### list-values
Get all subscriber emails with their field values (only contacts that have field values).
```bash
python3 scripts/sendiio_client.py list-values --id [encrypted_id]
```

### fields
Get available fields for one or more lists (POST /api/v1/fields).
```bash
python3 scripts/sendiio_client.py fields --lists [encrypted_id1,encrypted_id2]
```

### forms
List all opt-in forms.
```bash
python3 scripts/sendiio_client.py forms
```

### form-get
Get a form's details (including its generated HTML).
```bash
python3 scripts/sendiio_client.py form-get --id [form_id]
```

### form-edit
Point a form at a list + set redirect URLs.
```bash
python3 scripts/sendiio_client.py form-edit --id [form_id] --name "Affiliate Opt-in" --list-id [encrypted_id] --ok-url https://thankyou.page --dup-url https://already.subscribed
```

### form-del
Delete a form.
```bash
python3 scripts/sendiio_client.py form-del --id [form_id]
```

### stats
Per-email sequence stats (sent/opened/clicked/bounced/unsub). Optional date range.
```bash
python3 scripts/sendiio_client.py stats --seq [sequence_id]
python3 scripts/sendiio_client.py stats --seq [sequence_id] --from 2026-08-01 --to 2026-08-19
```

### webhooks
List webhook subscriptions.
```bash
python3 scripts/sendiio_client.py webhooks
```

### webhook-add
Register events → POST to your URL (email_added, opened, clicked, unsubscribed).
```bash
python3 scripts/sendiio_client.py webhook-add --url https://your-endpoint.example/hook --events email_added,clicked
```

### webhook-del
Remove a webhook by id.
```bash
python3 scripts/sendiio_client.py webhook-del --id [webhook_id]
```

## Dashboard-only operations (no API)

- **Creating lists** — sendiio.com → Email → Lists → Add List
- **Creating sequences** — sendiio.com → Email → Sequences → build the 7-email flow,
  then attach the sequence to the list so it auto-fires on subscribe

## Recommended affiliate pipeline

1. Dashboard: create list "Affiliate Campaigns" + 7-email sequence, attach to list
2. `make_poplinks.py add --slug [product] --url [affiliate-url]` → branded link
3. Pre-sell page form → `subscribe` (public) → sequence fires automatically
4. `webhook-add --events email_added` → Telegram alert on every new lead
5. `stats --seq [id]` → conversion tracking per email
