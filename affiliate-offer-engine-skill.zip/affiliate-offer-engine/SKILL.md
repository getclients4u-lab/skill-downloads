# Affiliate Offer Engine Skill - Complete Instructions

## ⚠️ CRITICAL: WORKFLOW CREATION CHECKLIST (Step 11)

**BEFORE YOU CREATE ANY SEQUENCE, REMEMBER:**

The email sequence needs 5 sub-steps. If you skip any, emails WON'T SEND:

- [ ] Step 11.1: Create the list + 7-email sequence in the Sendiio dashboard
- [ ] Step 11.2: Attach the sequence to the list (auto-fires on subscribe)
- [ ] Step 11.3: Wire the opt-in form to subscribe (NO WIRING = NEVER TRIGGERS)
- [ ] Step 11.4: Test with a real subscribe (`sendiio_client.py subscribe`)
- [ ] Step 11.5: Verify email 1 fires + webhook alert lands

**No API keys needed — replacements:**
- PageSprout/PopLinks → `make_poplinks.py` (Vercel redirects)
- Global Control tags/workflows → Sendiio (auto-fire sequences, custom fields as tags)
- Email sending → Sendiio (configured, auto-fire sequences) or AgentMail fallback + `lead_store.py` cron

---

## What This Skill Does

The Affiliate Offer Engine finds high-converting affiliate offers, analyzes them, and generates a complete promotional campaign — including pre-sells, bonuses, email sequences, and deployment. It's designed to save hours of manual work and deploy everything automatically.

## Master Templates (Use These for All Pages)

**ALWAYS fetch and model from these templates:**

1. **Sales Page Template:** https://sales-page-template-wine.vercel.app
   - Use for: Main affiliate sales pages (Step 5)
   - Extract: Hero section, benefit cards, CTA buttons, testimonial layout, gradient backgrounds, animations
   - This is the MASTER template - never modify this URL

2. **Bonus Delivery Page Template:** https://delivery-template-delta.vercel.app
   - Use for: All bonus delivery pages (Step 7)
   - Extract: Card layout, numbered badges, value banners, success badge, shimmer effects, floating animations, particles
   - This is the MASTER template - never modify this URL

**When creating any page:**
1. Fetch the reference template HTML
2. Study the layout structure, animations, card patterns
3. Apply product's brand colors/fonts to the template structure
4. Keep all design elements (badges, shimmer, particles, card floats)

## Trigger

Activate when someone types:
- `/affiliate offer`
- `/find offer`
- `/promo builder`
- "find me an affiliate offer"
- "build affiliate promo"
- "find a launch to promote"

## When This Skill Activates

**YOU MUST COMPLETE ALL 11 STEPS IN ORDER. DO NOT SKIP STEP 11.**

Step 11 has 5 mandatory sub-steps (see checklist at top of this file).

**At the end of Step 11, you MUST:**
1. Create the Sendiio list + 7-email sequence (dashboard, one-time)
2. Wire the opt-in form to subscribe to the list (public endpoint)
3. Test-fire a real subscribe and verify email 1 sends
4. Register the `email_added` webhook → Telegram alert

**If you finish without doing Step 11.3 (form wiring), you have FAILED — the sequence will never trigger.**

---

## The Workflow

**Note on API Keys:** 
- Try to use the API key when you need it
- Only ask for the key if it's missing or the connection fails
- Don't check upfront - just attempt the operation

---

### STEP 1: Get Affiliate Offer (Two Paths)

Ask:
> "Do you have an affiliate offer URL, or would you like me to find something to promote on the launch calendar?"
> 
> 1. I have a URL
> 2. Find me a launch

**If they choose 1 (Have URL):**
- Ask: "What's the URL to the affiliate offer?"
- Wait for user to provide the link
- Proceed to Step 2

**If they choose 2 (Find Launch):**

1. **Ask filter preference:**
   > "Do you want: 1. Big Launches 2. Normal Launches 3. All Launches"

2. **Ask timeframe:**
   > "How many days ahead? (7, 30, 60, 90)"

3. **Run the Muncheye scraper:**
   ```bash
   python3 ~/.openclaw/workspace/skills/affiliate-offer-engine/scripts/muncheye_scraper.py --days [DAYS] --filter [all|big|normal] --format table
   ```

4. **Display launches in table format:**
   ```
   #   Date    Product                          Price  Comm
   ──────────────────────────────────────────────────────
   1   May 14  ProfitPilot AI                   $67    50%
   2   May 15  Build apps with AI               $27    50%
   ...
   ```

5. **User picks a number**

6. **Fetch JV page details:**
   - Get the Muncheye URL from script output (JSON format)
   - Curl the Muncheye page to find JV page URL
   - Fetch JV page for full details
   - Extract: Sales page URL, affiliate link, commission, prizes

7. **Display launch summary and proceed to Step 2**

---

### STEP 2: Analyze Product + Create PopLink

**If user came from Path 1 (provided URL):**

1. **Follow the affiliate link** to identify the product/destination
2. **Search for affiliate program details:**
   - Look for "Affiliate", "Partners", "JV" links on the site
   - Search web: `[product name] affiliate program`
   - Check affiliate program databases
3. **Extract affiliate details:**
   - Commission rate & structure (one-time or recurring)
   - Cookie duration
   - Affiliate page URL
   - Payout terms
   - Any bonuses/contests for affiliates

4. **THEN analyze the sales page** for product details:
   - Product name and tagline
   - Price point(s)
   - Main features/benefits
   - Target audience
   - Key hooks/angles
   - Social proof/testimonials
   - **Design elements (EXTRACT THESE THOROUGHLY):**
     - Primary color (hex code)
     - Secondary/accent color (hex code)
     - Background color(s) (hex codes)
     - Font families (e.g., 'Inter', 'Roboto', system fonts)
     - Font sizes for headings (h1, h2, h3)
     - Button style (colors, border-radius, shadows, hover effects)
     - Layout patterns (card grids, sections, spacing)
     - Animations/effects (gradients, particles, hover states)
     - Border styles, shadows, rounded corners

5. **Create PopLink IMMEDIATELY (no API — Vercel redirect):**
   - Slug: [product-name] or relevant keyword
   - Destination: affiliate link provided
   - Run: `python3 skills/affiliate-offer-engine/scripts/make_poplinks.py add --slug [slug] --url "[affiliate-url]"`
   - Result: `https://<campaign-domain>/[slug]` (branded link, same as PageSprout PopLink)
   - The campaign's `vercel.json` gets a `redirects` entry on deploy — no PageSprout, no API key
   - Optional click tracking: add `?ref=[slug]` to the destination URL and count hits in Vercel analytics

6. **Create design extraction document:**
   Save as `[product]-design-system.md` with:
   ```markdown
   # [Product Name] Design System
   
   ## Colors
   - Primary: #XXXXXX
   - Secondary: #XXXXXX
   - Background: #XXXXXX
   - Text: #XXXXXX
   - Accent: #XXXXXX
   
   ## Typography
   - Font Family: 'Font Name', sans-serif
   - H1: XXpx, weight XXX
   - H2: XXpx, weight XXX
   - Body: XXpx, line-height X.X
   
   ## Buttons
   - Background: gradient(XXdeg, #XXX, #XXX)
   - Border-radius: XXpx
   - Padding: XXpx XXpx
   - Shadow: 0 XXpx XXpx rgba(...)
   - Hover: transform, shadow changes
   
   ## Cards/Sections
   - Background: #XXXXXX or rgba(...)
   - Border: Xpx solid #XXX
   - Border-radius: XXpx
   - Padding: XXpx
   
   ## Effects
   - [ ] Animated background gradients
   - [ ] Floating particles
   - [ ] Button shimmer on hover
   - [ ] Card float animations
   - [ ] Badge pulse
   ```

7. **Return formatted analysis:**
```
🔍 AFFILIATE PROGRAM & OFFER DETAILS

**Product:** [Name]
**Your Affiliate Link:** [URL provided]
**Your PopLink:** https://<campaign-domain>/[slug] ✓ (Vercel redirect — no API)

**Affiliate Program:**
- Commission: [% and structure]
- Cookie Duration: [days]
- Affiliate Page: [URL]
- Payout Terms: [details]

**Product Details:**
- What it does: [1-2 sentence summary]
- Price: $[amount]
- Target Audience: [who it's for]

**Key Features:**
- [Feature 1]
- [Feature 2]
- [Feature 3]

**Main Hooks/Angles:**
1. [Hook 1]
2. [Hook 2]
3. [Hook 3]

**Design Notes:** [colors, style observed on sales page]
```

---

### STEP 3: Generate Hooks for the Offer

Based on sales page analysis, create 5-7 compelling hooks:

```
🪝 HOOKS FOR [PRODUCT NAME]

1. [Hook angle - curiosity-driven]
2. [Hook angle - pain point focused]
3. [Hook angle - result/outcome focused]
4. [Hook angle - time-saving angle]
5. [Hook angle - comparison/contrast]
6. [Hook angle - social proof angle]
7. [Hook angle - urgency/scarcity]
```

---

### STEP 4: List 3 HIGH QUALITY Pre-Sell Freebies

Create 3 pre-sell resources that are CONGRUENT to the offer (make them want the product MORE after consuming). These must be HTML/CSS/JS tools I can build and deploy myself.

**IMPORTANT:** Each pre-sell must be a DIFFERENT TYPE:
- **Pre-Sell #1:** Calculator/Assessment Tool (quantifies their problem)
- **Pre-Sell #2:** Generator/Template Tool (gives them something to use)
- **Pre-Sell #3:** Educational Resource (teaches them why they need the solution)

**OPTIONAL PRE-SELL TYPES (if applicable):**
- **Competitor Comparison:** Tool comparing product to 2-3 alternatives
- **Social Proof Widget:** Live counter showing "X people using this"
- **Exit Intent Popup:** Capture email before they leave

**Deployment Setup:**
- Build each as HTML/CSS/JS pages
- Deploy to Vercel default domains
- Use Vercel's free tier

```
📚 PRE-SELL RESOURCES (3 Total - Different Types)

**PRE-SELL #1: [Name] - CALCULATOR/ASSESSMENT**
- Type: Interactive calculator or assessment
- What it does: [quantifies their pain/problem]
- Why it works: [shows them the cost of not solving it]
- CTA: Soft pitch to main offer
- GC Tag: fires "int-[product]" on engagement
- URL: presell-1.vercel.app

**PRE-SELL #2: [Name] - GENERATOR/TEMPLATE**
- Type: Tool that generates something they can use
- What it does: [creates content/templates they need]
- Why it works: [shows value but reveals they need more]
- CTA: Soft pitch to main offer
- GC Tag: fires "int-[product]" on engagement
- URL: presell-2.vercel.app

**PRE-SELL #3: [Name] - EDUCATIONAL RESOURCE**
- Type: Guide, roadmap, or educational tool
- What it does: [teaches the strategy but not execution]
- Why it works: [educates then shows tool makes it easier]
- CTA: Soft pitch to main offer
- GC Tag: fires "int-[product]" on engagement
- URL: presell-3.vercel.app
```

---

### STEP 5: List 3 HIGH QUALITY Bonuses

Create 3 bonuses that complement the main offer. These must be HTML/CSS/JS tools I can build and deploy myself.

**IMPORTANT:** Each bonus must be a DIFFERENT TYPE:
- **Bonus #1:** Implementation Tool (helps them use the product)
- **Bonus #2:** Strategy/Planning Tool (helps them plan)
- **Bonus #3:** Optimization/Tracking Tool (helps them improve)

**OPTIONAL BONUS TYPES:**
- **ROI Calculator:** Shows return on investment over time (powerful for B2B)

```
🎁 BONUSES (3 Total - Different Types)

**BONUS #1: [Name] - IMPLEMENTATION TOOL ($X Value)**
- Type: Tool that helps implement what they bought
- What it does: [makes using the product easier/faster]
- Why it matters: [removes friction from implementation]
- URL: bonus-1.vercel.app

**BONUS #2: [Name] - STRATEGY/PLANNING TOOL ($X Value)**
- Type: Planning, calendar, or strategy tool
- What it does: [helps them plan their approach]
- Why it matters: [gives them a system/framework]
- URL: bonus-2.vercel.app

**BONUS #3: [Name] - OPTIMIZATION/TRACKING TOOL ($X Value)**
- Type: Analytics, tracking, or optimization tool
- What it does: [helps them track and improve results]
- Why it matters: [shows ROI and improvement over time]
- URL: bonus-3.vercel.app

**TOTAL BONUS VALUE:** $XXX
```

---

### STEP 6: Get Approval

Present everything to user:
```
📋 CAMPAIGN OVERVIEW

**Product:** [Name]
**PopLink:** https://<campaign-domain>/[slug] ✓
**Hooks:** [List of 5-7]

**Pre-Sells (3 Different Types):**
1. [Type 1 - Calculator/Assessment]: [Name]
2. [Type 2 - Generator/Template]: [Name]
3. [Type 3 - Educational]: [Name]

**Bonuses (3 Different Types):**
1. [Type 1 - Implementation]: [Name] ($X)
2. [Type 2 - Strategy]: [Name] ($X)
3. [Type 3 - Optimization]: [Name] ($X)

**Total Bonus Value:** $XXX

Ready to build? (yes/no)
```

Wait for approval before proceeding.

---

### STEP 7: Build Pre-Sells, Bonuses, Sales Page & Bonus Delivery Page

Once approved:

1. **Build all pages locally** in `[product]-campaign/` folder:
   - `presells/presell-1/`, `presell-2/`, `presell-3/` - 3 different types
   - `bonuses/bonus-1/`, `bonus-2/`, `bonus-3/` - 3 different types
   - `bonuses/index.html` - BONUS DELIVERY PAGE (for post-purchase)
   - `sales-page/index.html` - main sales page with product branding

2. **Sales Page Design:**
   - **CRITICAL: Visit the affiliate link and EXTRACT the actual design from the product's sales page**
     - Use `curl` or browser tools to fetch the actual HTML/CSS
     - Screenshot the page if needed to capture colors, fonts, layout
     - Identify: color scheme, primary colors, font families, button styles, layout patterns
     - Note: spacing, animations, card styles, section backgrounds
   - **MATCH the product's design EXACTLY** (colors, fonts, layout, style)
   - Use the SAME color palette as the original (primary, accent, background colors)
   - Use the SAME or similar fonts (match font families from the original)
   - Replicate layout patterns (hero structure, card grids, section styling)
   - Copy animation styles if present (particles, gradients, hover effects)
   - Include: hero, problem, solution, features, testimonials, how-it-works
   - Feature ALL 3 bonuses in dedicated section
   - Strong CTAs throughout using PopLink
   - Mobile responsive
   - **Optional:** A/B test 2 versions of headline/CTA

3. **Bonus Delivery Page** (`bonuses/index.html`):
   - For people who ALREADY PURCHASED
   - Welcome message: "Here's your bonus package"
   - List all 3 bonuses with access links
   - Clear instructions on how to use each
   - Support/contact info if they have issues
   - Optional: CTA to join community/follow up

4. **Deploy to Vercel** (default domains):
   - Each presell: `presell-1.vercel.app`, etc.
   - Each bonus: `bonus-1.vercel.app`, etc.
   - Bonus delivery: `bonuses-eight.vercel.app` (or similar)
   - Sales page: `sales-page-[random].vercel.app`

5. **Create GitHub repo** and push all code

6. **Test all live links** before delivering to user

---

### STEP 8: Create Interest Tag (Sendiio custom field)

**With Sendiio:** the tag is just a custom field on the contact. Pass it at subscribe time and it's stored automatically:

```bash
python3 skills/affiliate-offer-engine/scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email lead@example.com --first Name --tag int-[product-name]
```

**Local fallback (no Sendiio):** use the local lead store:

```bash
python3 skills/affiliate-offer-engine/scripts/lead_store.py add --email lead@example.com --first Name --tag int-[product-name]
```

Tags are stored in `leads.json` in the campaign folder (fallback only). The tag name IS the trigger key used by the sequence.

---

### STEP 9: Write 3 Pre-Sell Emails

Create 3 emails driving to pre-sell pages:

**Email 1:** Problem awareness → Calculator/Assessment pre-sell
**Email 2:** Solution interest → Generator/Template pre-sell  
**Email 3:** Decision → Educational pre-sell + direct pitch

Each email:
- Links to specific pre-sell page
- Fires interest tag on click (e.g., `int-guruos` or `get10clients`)
- Short, punchy, curiosity-driven
- Builds toward the sale
- Uses "Click here to [action]" format

**Subject Line Pattern:**
- Email 1: Question about cost/problem ("How much is your info business costing you?")
- Email 2: Benefit + time frame ("10 course ideas for you (generated in 10 seconds)")
- Email 3: Number + result ("The 7 steps to a 7-figure info business")

Save as file for user to download.

---

### STEP 10: Write 7-Part Sales Email Sequence

Create full sales sequence (triggered when interest tag fires):

**Email 1:** Introduction + problem agitation (immediate)
**Email 2:** Solution reveal - the AI team (Day 2)
**Email 3:** Features + benefits deep dive (Day 3)
**Email 4:** Social proof + testimonials (Day 4)
**Email 5:** Objection handling (Day 5)
**Email 6:** Bonus stack reveal (Day 6)
**Email 7:** Final call / cart close (Day 7)

All emails use PopLink: `https://<campaign-domain>/[slug]`

**Subject Line Pattern:**
| Email | Subject Style | Example |
|-------|--------------|---------|
| 1 | Problem-focused | "The 'I don't have time' problem" |
| 2 | Curiosity/Discovery | "Meet your new AI team" |
| 3 | Educational | "What exactly do you get with [Product]?" |
| 4 | Social Proof | "$34K in profit (first launch)" |
| 5 | Objection Handler | "'But I'm not tech-savvy...'" |
| 6 | Value/Bonus | "$211 in bonuses (yours free)" |
| 7 | Urgency | "⏰ Cart closes at midnight (last chance)" |

---

### STEP 11: Deploy Email Sequence (Sendiio native sequences — preferred, no cron needed)

**⚠️ RECOMMENDED PATH: Sendiio sequences fire automatically when a lead subscribes — no cron, no local store needed.**

#### Step 11.1: Create the list + sequence in Sendiio
1. In Sendiio dashboard: Email → Lists → Add List (e.g. "Affiliate Campaigns")
2. Copy the list's encrypted_id (or run `python3 scripts/sendiio_client.py lists`)
3. Email → Sequences → create the 7-email sequence (email 1 immediate, then 2-day gaps) — paste your campaign emails
4. Attach the sequence to the list so it fires on subscribe

#### Step 11.2: Wire the opt-in form (the trigger)
The pre-sell page's email form subscribes directly (public endpoint):
```bash
python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email lead@example.com --first Name --tag int-[product]
```
Or use the public form action: `POST https://sendiio.com/api/v1/lists/subscribe/json` with `email_list_id`, `email`, plus any extra fields (they're stored on the contact).

#### Step 11.3: Test the sequence
```bash
python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email test@example.com --first Test
```
Verify: contact appears in Sendiio, email 1 fires immediately, subsequent emails follow the sequence timing.

**If you skip Step 11.2 (form wiring), the sequence will NEVER trigger.**

---

### STEP 11-alt: Local cron fallback (no Sendiio)

#### Step 11.1: Save the 7 emails as files
Save each email as `campaign/emails/email-1.html` … `email-7.html` (subject line in the HTML `<title>`, body in `<body>`). These are your flows.

#### Step 11.2: Add leads (sending is via AgentMail)
When someone opts in (form on pre-sell page, manual entry, or webhook):
```bash
python3 skills/affiliate-offer-engine/scripts/lead_store.py add --email lead@example.com --first Name --tag int-[product-name]
```

#### Step 11.3: Create the cron job (instead of email flows)
Create an OpenClaw cron job (daily) that:
1. Runs `python3 skills/affiliate-offer-engine/scripts/lead_store.py due --tag int-[product-name]`
2. For each due lead, sends `campaign/emails/email-{step+1}.html` via AgentMail (use `text` param, not `body`)
3. Runs `python3 skills/affiliate-offer-engine/scripts/lead_store.py advance --email [email] --step [step+1]`

Delays are handled by `lead_store.py` (email 1 immediate, then 2-day gaps — see `SEQUENCE_DELAY_DAYS`).

#### Step 11.4: Wire the opt-in form (instead of linking a tag)
On each pre-sell page, the email capture form must call a small endpoint (Vercel function or the campaign API) that runs `lead_store.py add --email ... --tag int-[product-name]`. This is what "fires" the sequence trigger.

#### Step 11.5: Test the sequence
```bash
python3 skills/affiliate-offer-engine/scripts/lead_store.py add --email test@example.com --first Test --tag int-[product-name]
python3 skills/affiliate-offer-engine/scripts/lead_store.py due --tag int-[product-name]
```
Verify: lead appears in `due`, email-1 sends, `advance` moves the lead to step 1.

**If you skip Step 11.3 (cron), emails will NOT send.**  
**If you skip Step 11.4 (form wiring), the sequence will NEVER trigger.**
**Workflow Goal:** Convert tagged users into buyers via 7-email sequence

---

## Output Rules

- **NEVER** invent commissions, prices, or features — pull from sales page only
- All emails must follow "Click here to [action]" format
- Pre-sells must be CONGRUENT (make them want product MORE, not random freebies)
- Bonuses must complement the offer, not compete with it
- Sales page must MATCH the product's design style EXACTLY (colors, fonts, layout)
- Everything deploy-ready with LIVE LINKS before marking complete
- Provide all URLs to user for testing

---

## Tools Used

- `web_fetch` / `browser` — analyze sales pages
- `web_search` — find affiliate program details
- `write` — create HTML/CSS/JS pages
- `exec` — deploy to Vercel via CLI
- `image` — capture screenshots for design reference
- `make_poplinks.py` — create branded links via Vercel redirects (Step 2, no API)
- `sendiio_client.py` — full Sendiio wrapper (16 commands: check, lists, subscribe, unsubscribe, list-get, list-fields, list-values, forms, form-get, form-edit, form-del, fields, stats, webhooks, webhook-add, webhook-del)
- `lead_store.py` + OpenClaw cron — local lead tags and email sequence (Step 11-alt fallback, no API)
- File write — create email ZIP files

---

## Page Templates

### Sales Page Structure (Match Product Design)

**CRITICAL:** Before building, create a design extraction document with:
- Primary color (hex)
- Secondary color (hex)  
- Background color (hex)
- Font family
- Button styles (border-radius, shadows)
- Card/section styling patterns

Then build:
```
- Countdown Timer Bar (optional - for launches/special pricing)
- Header (sticky nav + logo + CTA)
- Hero (badge + headline + subheadline + CTA button)
- Trust Bar (ratings, user count)
- Demo/Video Section
- How It Works (3 steps)
- Features Grid (4-6 cards)
- Testimonials (2-3 with stats)
- Bonuses Section (feature all 3 bonuses)
- Final CTA
- Footer
```

**All colors, fonts, and styles must match the extracted design from Step 2.**

---

## Animation & Effects Library

**IMPORTANT:** Replace the color values in these templates with the ACTUAL colors extracted from the product's sales page in Step 2.

Example replacements:
- `rgba(124,58,237,X)` → Use extracted primary color with opacity X
- `#7c3aed`, `#a855f7` → Use extracted primary/accent colors
- `#fff` → Use extracted text color (usually white or dark)

Use these CSS animations to make pages feel premium and high-converting:

### 1. Animated Background (Pulsing Gradients)
```css
.bg-animation {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    z-index: -1;
    background: 
        radial-gradient(ellipse at 20% 20%, rgba(124,58,237,0.15) 0%, transparent 50%),
        radial-gradient(ellipse at 80% 80%, rgba(168,85,247,0.1) 0%, transparent 50%),
        radial-gradient(ellipse at 50% 50%, rgba(124,58,237,0.05) 0%, transparent 70%);
    animation: bgPulse 8s ease-in-out infinite;
}
@keyframes bgPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
}
```

### 2. Floating Particles
```css
.particles {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    z-index: -1;
    overflow: hidden;
}
.particle {
    position: absolute;
    width: 4px; height: 4px;
    background: rgba(124,58,237,0.6);
    border-radius: 50%;
    animation: float 15s infinite;
}
/* Add 10 particles with different left positions and delays */
@keyframes float {
    0%, 100% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
    10% { opacity: 1; }
    90% { opacity: 1; }
    100% { transform: translateY(-100vh) rotate(720deg); opacity: 0; }
}
```

### 3. Glowing Badge Pulse
```css
.hero-badge {
    animation: badgePulse 2s ease-in-out infinite;
}
@keyframes badgePulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(124,58,237,0.4); }
    50% { box-shadow: 0 0 20px 5px rgba(124,58,237,0.2); }
}
```

### 4. Title Glow Effect
```css
.hero h1 {
    background: linear-gradient(135deg, #fff 0%, #a855f7 50%, #7c3aed 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: titleGlow 3s ease-in-out infinite;
}
@keyframes titleGlow {
    0%, 100% { filter: brightness(1); }
    50% { filter: brightness(1.2); }
}
```

### 5. Button Shine Effect
```css
.cta-button {
    position: relative;
    overflow: hidden;
}
.cta-button::before {
    content: '';
    position: absolute;
    top: 0; left: -100%;
    width: 100%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
}
.cta-button:hover::before {
    left: 100%;
}
```

### 6. Card Float Animation
```css
.card {
    animation: cardFloat 6s ease-in-out infinite;
}
.card:nth-child(1) { animation-delay: 0s; }
.card:nth-child(2) { animation-delay: 2s; }
.card:nth-child(3) { animation-delay: 4s; }
@keyframes cardFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}
```

### 7. Icon Bounce
```css
.feature-icon {
    animation: iconBounce 2s ease infinite;
}
@keyframes iconBounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}
```

### 8. Number Glow Pulse
```css
.step-number {
    animation: numberGlow 2s ease-in-out infinite;
}
@keyframes numberGlow {
    0%, 100% { box-shadow: 0 10px 30px rgba(124,58,237,0.4); }
    50% { box-shadow: 0 10px 40px rgba(124,58,237,0.6); }
}
```

### 9. Shimmer Effect (for value banners)
```css
.value-banner::before {
    content: '';
    position: absolute;
    top: -50%; left: -50%;
    width: 200%; height: 200%;
    background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
    animation: shimmer 3s infinite;
}
@keyframes shimmer {
    0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
    100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
}
```

### 10. Stat Pulse
```css
.testimonial-stat {
    animation: statPulse 2s ease-in-out infinite;
}
@keyframes statPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}
```

---

## Countdown Timer (For Launches)

Add urgency with a countdown timer bar at the top of sales pages:

### HTML
```html
<div class="countdown-bar">
    <div class="container">
        <div class="countdown-inner">
            <span class="countdown-label">⏰ Special Launch Pricing Ends In:</span>
            <div class="countdown-timer" id="countdown">
                <div class="time-unit">
                    <span class="time-value" id="days">00</span>
                    <span class="time-label">Days</span>
                </div>
                <div class="time-separator">:</div>
                <div class="time-unit">
                    <span class="time-value" id="hours">00</span>
                    <span class="time-label">Hours</span>
                </div>
                <div class="time-separator">:</div>
                <div class="time-unit">
                    <span class="time-value" id="minutes">00</span>
                    <span class="time-label">Mins</span>
                </div>
                <div class="time-separator">:</div>
                <div class="time-unit">
                    <span class="time-value" id="seconds">00</span>
                    <span class="time-label">Secs</span>
                </div>
            </div>
        </div>
    </div>
</div>
```

### CSS
```css
.countdown-bar {
    background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%);
    padding: 15px 0;
    position: sticky;
    top: 0;
    z-index: 101;
    box-shadow: 0 4px 20px rgba(124,58,237,0.4);
    animation: countdownPulse 2s ease-in-out infinite;
}
@keyframes countdownPulse {
    0%, 100% { box-shadow: 0 4px 20px rgba(124,58,237,0.4); }
    50% { box-shadow: 0 4px 30px rgba(124,58,237,0.6); }
}
.countdown-inner {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 30px;
    flex-wrap: wrap;
}
.countdown-label {
    font-weight: 700;
    font-size: 16px;
    color: #fff;
    text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}
.countdown-timer {
    display: flex;
    align-items: center;
    gap: 10px;
}
.time-unit {
    background: rgba(255,255,255,0.2);
    border-radius: 8px;
    padding: 10px 15px;
    text-align: center;
    min-width: 60px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
}
.time-value {
    display: block;
    font-size: 28px;
    font-weight: 800;
    color: #fff;
    line-height: 1;
    text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}
.time-label {
    display: block;
    font-size: 11px;
    color: rgba(255,255,255,0.8);
    text-transform: uppercase;
    margin-top: 4px;
    letter-spacing: 1px;
}
.time-separator {
    font-size: 28px;
    font-weight: 800;
    color: #fff;
    animation: separatorBlink 1s ease-in-out infinite;
}
@keyframes separatorBlink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}
```

### JavaScript
```javascript
// Countdown Timer - Set your expiration date
const countdownDate = new Date('May 17, 2026 00:00:00').getTime();

function updateCountdown() {
    const now = new Date().getTime();
    const distance = countdownDate - now;
    
    if (distance < 0) {
        document.getElementById('countdown').innerHTML = '<div class="expired">OFFER EXPIRED</div>';
        return;
    }
    
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    document.getElementById('days').textContent = String(days).padStart(2, '0');
    document.getElementById('hours').textContent = String(hours).padStart(2, '0');
    document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
    document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
}

updateCountdown();
setInterval(updateCountdown, 1000);
```

### Pre-Sell Page Types
**Type 1 - Calculator/Assessment:**
- Input fields for their situation
- Calculation/assessment logic
- Results with insights
- CTA: "Want this solved automatically?"

**Type 2 - Generator/Template:**
- Input for what they need
- Generation logic
- Output they can copy/use
- CTA: "Want more like this automatically?"

**Type 3 - Educational:**
- Guide/roadmap content
- Step-by-step explanation
- "Here's what you need to do"
- CTA: "Want this done for you?"

**Optional - Competitor Comparison:**
- Compare product to 2-3 alternatives
- Show why this one is better
- Feature comparison table
- CTA: "See why [product] wins"

### Bonus Delivery Page (Post-Purchase)

**CRITICAL: Fetch and model from https://delivery-template-delta.vercel.app**

Process:
1. Fetch the reference template HTML
2. Extract all design patterns (see below)
3. Replace content with product-specific bonuses
4. Apply product's color scheme (keep structure intact)

Must include:
- **Success badge at top:** "[Product Name] Bonuses" (not generic "Bonus Hub")
- **Large gradient headline:** "Your [Product] Bonus Package"
- **Value banner with shimmer effect:** Total bonus value prominently displayed
- **Numbered bonus cards (1, 2, 3):**
  - Circular number badges (top-right, glowing)
  - Large emoji icons (bouncing animation)
  - Green value badges (e.g., "$97 Value")
  - Access button with shimmer effect
  - Card float animations (staggered delays)
  - Purple gradient top bar (4px)
  - Radial glow on hover
- **Support section:** Pulsing background, CTA to product dashboard
- **Footer:** Copyright/branding

**Design elements:**
- Animated gradient background
- Floating particles
- All using product's color scheme (extracted in Step 2)
- Match card layout, animations, and effects from reference page
