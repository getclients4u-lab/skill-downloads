# Affiliate Offer Engine - Complete Documentation

## What This Skill Does

The **Affiliate Offer Engine** is a complete affiliate campaign builder that:

1. **Finds launches** on Muncheye.com (or accepts your URL)
2. **Analyzes the product** and extracts design elements
3. **Creates branded links** via Vercel redirects (no PageSprout, no API)
4. **Generates 3 pre-sell pages** (calculators, generators, educational content)
5. **Builds 3 bonus pages** complementing the product
6. **Designs bonus delivery page** with all bonuses
7. **Writes emails** (3 pre-sell + 7-part sales sequence)
8. **Automates the sequence** via Sendiio sequences (auto-fire) or local lead store + cron (no Global Control, no API)
9. **Deploys everything** to Vercel
10. **Tests the funnel** end-to-end

**Result:** A complete, tested affiliate campaign ready to promote in under 30 minutes.

---

## Prerequisites

**No new API keys required.** Everything uses what we already have:

1. **Vercel + GitHub** (already configured) - deploy pages AND create branded redirect links
2. **Sendiio** (configured, user_id 12488 verified) - send the email sequence; auto-fires on subscribe
3. **OpenClaw cron** (built-in) - fallback email sequence runner (only if not using Sendiio)

**Email sending:** Sendiio is configured (token+secret stored, user_id 12488 verified) — its sequences auto-fire on subscribe, so campaigns need no cron. AgentMail remains as fallback.

---

## How to Use

### Quick Start

```
/affiliate offer
```

You'll be asked:
1. **Do you have a URL or want to find a launch?**
   - Option 1: Paste your affiliate URL
   - Option 2: Browse Muncheye launches

2. **If Option 2 - Pick launch type:**
   - Big Launches (price >= $37)
   - Normal Launches (price < $37)
   - All Launches

3. **Pick timeframe:** 7, 30, 60, or 90 days

4. **Select from table:** Pick a number from the launch list

5. **Sit back:** The skill builds the entire campaign

---

## What Gets Created

### Pages Deployed (6 total)

1. **Sales Page** - Main affiliate page with product pitch
2. **Pre-Sell 1** - Calculator/Assessment (captures interest)
3. **Pre-Sell 2** - Generator/Template (builds desire)
4. **Pre-Sell 3** - Educational content (final push)
5. **Bonus Delivery** - Post-purchase bonus hub
6. **Bonus Pages (3)** - Individual bonus tools

### Emails Written (10 total)

**Pre-Sell Sequence (3 emails):**
- Email 1: Problem awareness → Calculator
- Email 2: Solution interest → Generator
- Email 3: Decision → Educational + direct pitch

**Sales Sequence (7 emails):**
- Day 0: Problem agitation
- Day 2: Solution reveal
- Day 3: Features + benefits
- Day 4: Social proof + testimonials
- Day 5: Objection handling
- Day 6: Bonus stack reveal
- Day 7: Final call / urgency

### Automation Setup (no API)

- **Lead Tag:** `int-[product-name]` (stored in `leads.json` via `lead_store.py`)
- **Sequence:** 7-email run by a daily OpenClaw cron
- **Trigger:** Opt-in form wired to `lead_store.py add`
- **Sending:** Sendiio (auto-fire sequences) or AgentMail fallback

---

## Campaign Flow

```
Pre-Sell Email
    ↓
Calculator/Tool (fires int-[product] tag)
    ↓
7-Email Sales Sequence (auto-triggered)
    ↓
Sales Page → PopLink → Affiliate Offer
    ↓
Purchase → Bonus Delivery Page
    ↓
3 Bonus Tools
```

---

## File Structure

```
~/.openclaw/workspace/
├── skills/affiliate-offer-engine/
│   ├── SKILL.md                    # Main skill instructions
│   ├── README.md                   # This file
│   └── scripts/
│       └── muncheye_scraper.py     # Launch calendar scraper
│
├── master-templates/
│   ├── sales-page-template/        # Master sales page design
│   └── delivery-template/          # Master bonus delivery design
│
└── [product-name]-campaign/        # Created per campaign
    ├── sales-page/
    ├── presells/
    │   ├── presell-1/
    │   ├── presell-2/
    │   └── presell-3/
    ├── bonuses/
    │   ├── bonus-1/
    │   ├── bonus-2/
    │   ├── bonus-3/
    │   └── delivery/
    ├── emails/
    │   ├── presell-emails.md
    │   └── sales-sequence.md
    ├── design-system.md
    └── campaign-summary.md
```

---

## Muncheye Scraper Usage

The skill includes a Python scraper for finding launches:

```bash
# Find big launches in next 7 days
python3 scripts/muncheye_scraper.py --days 7 --filter big

# Find all launches in next 30 days
python3 scripts/muncheye_scraper.py --days 30 --filter all

# Get JSON output
python3 scripts/muncheye_scraper.py --days 7 --format json
```

**Output Format:**
```
#   Date    Product                          Price  Comm
────────────────────────────────────────────────────────
1   May 14  ProfitPilot AI                   $67    50%
2   May 15  Build apps with AI               $27    50%
...
```

---

## Master Templates

The skill uses two master templates that provide proven, high-converting designs:

### 1. Sales Page Template
**URL:** https://sales-page-template-wine.vercel.app

**Elements to extract:**
- Hero section with gradient headline
- Benefit cards grid
- CTA buttons with hover effects
- Testimonial layout
- Pricing section
- Guarantee badge
- Footer

### 2. Bonus Delivery Template
**URL:** https://delivery-template-delta.vercel.app

**Elements to extract:**
- Success badge (animated pulse)
- Value banner (shimmer effect)
- Numbered bonus cards (1, 2, 3)
- Card float animations
- Emoji icons (bouncing)
- Green value badges
- Support section

**The skill automatically:**
1. Fetches these templates
2. Extracts the design patterns
3. Applies the product's brand colors
4. Keeps all animations and effects

---

## Email Sequence Automation

### Preferred: Sendiio native sequences (auto-fire, no cron)
- Create list + 7-email sequence in the Sendiio dashboard (one-time)
- Pre-sell opt-in form → `scripts/sendiio_client.py subscribe` (public endpoint)
- Sequence fires automatically: email 1 immediate, then 2-day gaps
- Full Sendiio reference: `references/sendiio-client.md`
- Optional webhook: `webhook-add --events email_added` → Telegram alert per lead
- Tracking: `stats --seq [id]` → per-email opens/clicks/bounces

### Fallback: local lead store + daily cron (no Sendiio)
- Tags: `int-[product-name]` stored locally in `leads.json` via `scripts/lead_store.py`
- A lead is added when someone engages with pre-sell content (opt-in form wired to `lead_store.py add`)
- This triggers the 7-email sequence

### Sequence Structure (Sendiio timing; lead_store.py uses the same)
```
Email 1 (Day 0) → 2-day gap →
Email 2 (Day 2) → 1-day gap →
Email 3 (Day 3) → 1-day gap →
Email 4 (Day 4) → 1-day gap →
Email 5 (Day 5) → 1-day gap →
Email 6 (Day 6) → 1-day gap →
Email 7 (Day 7)
```

### CRITICAL: 5 Mandatory Steps (Sendiio path)

**The skill will NOT skip these:**

1. Create list + 7-email sequence in Sendiio dashboard, attach sequence to list
2. Get the list's encrypted_id (`sendiio_client.py lists`)
3. Wire the opt-in form to subscribe (public endpoint — sequence won't trigger without this)
4. Test-fire a real subscribe (`sendiio_client.py subscribe --list-id ... --email test@...`)
5. Verify email 1 fires + register `email_added` webhook

---

## Troubleshooting

### "No launches found"
- The scraper looks for launches in the specified timeframe
- Try expanding days (30, 60, 90)
- Check if Muncheye.com is accessible

### "PopLink returns 404"
- Regenerate redirects: `python3 scripts/make_poplinks.py generate --out vercel.json`
- Redeploy the campaign to Vercel

### "Emails not sending"
- Check the daily cron exists (`openclaw cron list`)
- Check `AGENTMAIL_API_KEY` is set
- Verify `campaign/emails/email-N.html` files exist

### "Pages not deploying"
- Check Vercel token is valid
- Verify internet connection
- Check Vercel account has available projects

---

## Best Practices

### Pre-Sell Content
- Must be CONGRUENT with the product
- Should make them want the product MORE
- Not random freebies or competing offers
- Interactive tools work best (calculators, generators)

### Bonuses
- Complement the main offer
- Don't compete with it
- High perceived value ($50-$100 each)
- Practical, immediately useful

### Email Copy
- Short paragraphs (1-3 sentences)
- 5th-grade readability
- Curiosity-driven subject lines
- Always "Click here to [action]" format
- P.S. with link mandatory

### Design
- Always use master templates
- Extract design from actual product page
- Match colors, fonts, layout exactly
- Keep all animations and effects

---

## Example Campaign

**Product:** ProfitPilot AI  
**Price:** $67 one-time  
**Commission:** 50% ($33.50 per sale)  

**Pre-Sells:**
1. Lead Gen ROI Calculator
2. Cold Email Template Generator
3. 7-Step Lead Gen Blueprint

**Bonuses:**
1. 100 Cold Email Templates ($97)
2. Lead Qualification Scorecard ($47)
3. CRM Setup Checklist ($67)

**Total Bonus Value:** $211

**Campaign Duration:** 7 days (launch window)  
**Expected Build Time:** 25-30 minutes

---

## Support

For skill issues or questions:
- Check SKILL.md for detailed workflow
- Review this README for examples
- Test with a known working launch first

---

## Version History

**v2.1** - Aug 2026
- Sendiio integrated: token+secret validated (user_id 12488), credentials stored
- New `scripts/sendiio_client.py` — full Sendiio API wrapper (16 commands: check, lists, subscribe, unsubscribe, list-get, list-fields, list-values, forms, form-get, form-edit, form-del, fields, stats, webhooks, webhook-add, webhook-del)
- Step 11 now prefers Sendiio native sequences (auto-fire on subscribe — no cron); local lead_store + cron kept as fallback
- New `references/sendiio-client.md` command reference
- skill.json → 2.1.0, requires sendiio

**v2.0** - Aug 2026
- No-API rewrite: PageSprout → Vercel redirects, Global Control → local lead store + OpenClaw cron
- New scripts: `make_poplinks.py`, `lead_store.py`

**v1.0** - May 2026
- Initial release
- Muncheye scraper integration
- Master templates
- Global Control automation (legacy, removed in v2.0)
- 5-step workflow safeguards

---

**Built with ❤️ for affiliate marketers who want to scale fast.**
