# Troubleshooting Guide - Common Issues & Solutions

> **Sendiio edition (v2.1).** PageSprout and Global Control are gone. Branded
> links use Vercel redirects (`make_poplinks.py`). The email sequence uses
> **Sendiio native sequences** (auto-fire on subscribe — preferred) with the
> local lead store (`lead_store.py`) + OpenClaw daily cron + AgentMail as fallback.

---

## Sendiio Issues

### "Invalid credentials supplied"
The token/secret pair is wrong or incomplete. Run:
```bash
python3 scripts/sendiio_client.py check
```
Expected: `OK — account user_id 12488`. If it fails, re-check `workspace/credentials/sendiio-key.txt` and `sendiio-secret.txt` (both required, chmod 600).

### "You don't have any email lists"
Lists can only be created in the dashboard (no API endpoint):
sendiio.com → Email → Lists → Add List. Then run `python3 scripts/sendiio_client.py lists` to get the encrypted_id.

### Subscribe fails "Specified 'email_list_id' is invalid"
You passed a numeric id for a post-2020 list. Lists created after July 2020 use **encrypted_id** (a long token), not the numeric id. Get it from `sendiio_client.py lists` or the dashboard's copy-list-id icon.

### Sequence fires but no email arrives
1. Verify the sequence is **attached to the list** (dashboard → sequence settings).
2. Verify the list has a sender name set (Email → Lists → edit → sender_name) — sequences can't send without a from-address.
3. Test: `python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email test@example.com` and check email 1 within minutes.

### No Telegram alert on new lead
Register the webhook (one-time):
```bash
python3 scripts/sendiio_client.py webhook-add --url https://your-endpoint/hook --events email_added
```
Then verify: `python3 scripts/sendiio_client.py webhooks`.

---

## ⚠️ CRITICAL ISSUES (These Will Break Your Campaign)

### Issue #1: Sequence Created But Emails Don't Send

**Symptoms:**
- Leads are in `leads.json`
- The cron runs
- But NO emails are being sent
- No errors shown

**Cause:** One of these:
1. The daily cron job was never created (Step 11.3) — this is the "SMTP" of the old system; without it, nothing sends.
2. The cron runs `due` but the send step is missing or failing (AgentMail key not set, or email file missing).
3. The cron sends but `advance` is not called, so the same lead stays "due" forever.

**Solution:**
1. Verify the cron exists: `openclaw cron list` — look for the campaign sequence job.
2. Test the pipeline manually:
   ```bash
   python3 scripts/lead_store.py add --email test@example.com --first Test --tag int-product
   python3 scripts/lead_store.py due --tag int-product
   ```
   Confirm the lead shows as due, then confirm the AgentMail send succeeds (check `AGENTMAIL_API_KEY` is set: `env | grep AGENTMAIL`).
3. Verify `campaign/emails/email-1.html` … `email-7.html` exist with subject in `<title>` and body in `<body>`.
4. Make sure the cron calls `advance --step N+1` after each successful send.

---

### Issue #2: Sequence Created But Never Triggers

**Symptoms:**
- Leads exist in the store
- Cron runs
- Email 1 never goes out for new leads

**Cause:** The opt-in form on the pre-sell page is not wired to add leads (Step 11.4). In the old system this was "link the tag to the workflow"; now it's "the form must call `lead_store.py add`".

**Solution:**
- Ensure the pre-sell form posts to the campaign endpoint (Vercel function) that runs:
  ```bash
  python3 scripts/lead_store.py add --email [email] --first [name] --tag int-[product]
  ```
- Test by adding a lead manually, then check `python3 scripts/lead_store.py due`.

---

### Issue #3: PopLink Redirect Returns 404

**Symptoms:**
- `https://<campaign-domain>/<slug>` gives 404

**Cause:** The redirects were added to `poplinks.json` but `vercel.json` was never regenerated or deployed.

**Solution:**
1. Regenerate: `python3 scripts/make_poplinks.py generate --out vercel.json`
2. Verify the redirect exists in `vercel.json` (`cat vercel.json`)
3. Redeploy the campaign to Vercel
4. Test: `curl -sI https://<campaign-domain>/<slug>` — expect `301`/`307` with `location:` header pointing at the affiliate URL

---

### Issue #4: Lead Added But Never Advances Past Step 0

**Symptoms:**
- `lead_store.py list` shows step 0 for days
- `lead_store.py due` shows the lead every day

**Cause:** The cron's `advance` step isn't running (same as #1), OR the send step fails silently so the sequence never advances.

**Solution:** Follow Issue #1 steps 2–4. The advance must happen only AFTER a successful send, so a failed send will correctly keep the lead due.

---

## Configuration Checks

### Verify the daily cron
```bash
openclaw cron list
```
Expected: a job named something like `[product] email sequence`, schedule daily.

### Verify AgentMail is configured
```bash
env | grep AGENTMAIL
```
If empty, set `AGENTMAIL_API_KEY` (already provisioned in this workspace).

### Verify email files
```bash
ls campaign/emails/
```
Expected: `email-1.html` … `email-7.html`.

---

## Legacy FAQ (Removed Dependencies)

### "PageSprout API key not found"
Not needed anymore. Branded links are Vercel redirects:
```bash
python3 scripts/make_poplinks.py add --slug myoffer --url "https://affiliate.example.com/?ref=you"
python3 scripts/make_poplinks.py generate --out vercel.json   # then deploy
```

### "Global Control API key not found"
Not needed anymore. Leads and sequences live locally:
```bash
python3 scripts/lead_store.py add --email lead@example.com --first Name --tag int-product
```

---

## Pre-Launch Checklist

- [ ] Sendiio list created (dashboard) + sequence attached to it
- [ ] `sendiio_client.py lists` returns the encrypted_id
- [ ] PopLinks generated: `poplinks.json` has entries + `vercel.json` deployed
- [ ] Redirect test passes: `curl -sI https://<campaign-domain>/<slug>` → 301/307
- [ ] Opt-in form wired to `subscribe` (public endpoint — Step 11.3)
- [ ] Test lead fires email 1 (Sendiio path)
- [ ] `email_added` webhook registered → Telegram alert works
- [ ] All CTAs link to the branded redirect, not raw affiliate URLs
