#!/usr/bin/env python3
"""
PopLink generator — Vercel redirects (PageSprout replacement).

Creates a `vercel.json` with a `redirects` array mapping branded slugs to
affiliate URLs. No API required: deploy the campaign project to Vercel and
`https://<your-domain>/<slug>` redirects to the affiliate link.

Usage:
  python3 make_poplinks.py add --slug profitpilot --url "https://affiliate.example.com/?ref=you"
  python3 make_poplinks.py list
  python3 make_poplinks.py generate --out vercel.json   # write redirects config
"""

import argparse
import json
import os
import sys

LINKS_FILE = os.environ.get("AOE_LINKS_FILE", os.path.join(os.path.dirname(__file__), "..", "poplinks.json"))
OUT_FILE = "vercel.json"


def load():
    if not os.path.exists(LINKS_FILE):
        return {}
    with open(LINKS_FILE) as f:
        return json.load(f)


def save(links):
    os.makedirs(os.path.dirname(LINKS_FILE), exist_ok=True)
    with open(LINKS_FILE, "w") as f:
        json.dump(links, f, indent=2)


def cmd_add(args):
    links = load()
    slug = args.slug.strip().lower().replace(" ", "-")
    links[slug] = args.url
    save(links)
    print(f"poplink: /{slug} -> {args.url}")
    return 0


def cmd_list(args):
    links = load()
    if not links:
        print("no poplinks")
        return 0
    for slug, url in links.items():
        print(f"/{slug} -> {url}")
    return 0


def cmd_generate(args):
    links = load()
    if not links:
        print("no poplinks to generate")
        return 1
    redirects = [
        {
            "source": f"/{slug}",
            "destination": url,
            "permanent": False,
        }
        for slug, url in links.items()
    ]
    cfg = {"redirects": redirects}
    out = args.out or OUT_FILE
    with open(out, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"wrote {out} with {len(redirects)} redirects")
    print("deploy to Vercel, then: https://<your-domain>/<slug> works as a PopLink")
    return 0


def main():
    p = argparse.ArgumentParser(description="PopLink generator (PageSprout replacement)")
    sub = p.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("add")
    pa.add_argument("--slug", required=True)
    pa.add_argument("--url", required=True)
    pa.set_defaults(fn=cmd_add)

    pl = sub.add_parser("list")
    pl.set_defaults(fn=cmd_list)

    pg = sub.add_parser("generate")
    pg.add_argument("--out", default=OUT_FILE)
    pg.set_defaults(fn=cmd_generate)

    args = p.parse_args()
    sys.exit(args.fn(args))


if __name__ == "__main__":
    main()
