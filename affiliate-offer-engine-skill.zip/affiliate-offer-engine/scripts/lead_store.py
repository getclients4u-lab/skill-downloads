#!/usr/bin/env python3
"""
Local lead store for the Affiliate Offer Engine (Global Control replacement).

No API required. Leads live in a JSON file; a daily OpenClaw cron advances
each lead through the 7-email sequence based on elapsed days.

Usage:
  python3 lead_store.py add --email a@b.com --first Jane --tag int-product
  python3 lead_store.py tag --email a@b.com --tag int-product
  python3 lead_store.py list [--tag int-product]
  python3 lead_store.py due            # leads whose next email is due (for cron)
  python3 lead_store.py advance --email a@b.com --step 2
  python3 lead_store.py stats
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

STORE = os.environ.get("AOE_LEAD_STORE", os.path.join(os.path.dirname(__file__), "..", "leads.json"))

# Days between sequence emails (matches the 7-email sales sequence)
SEQUENCE_DELAY_DAYS = [0, 2, 3, 4, 5, 6, 7]


def load():
    if not os.path.exists(STORE):
        return []
    with open(STORE) as f:
        return json.load(f)


def save(leads):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(leads, f, indent=2)
    os.replace(tmp, STORE)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def find(leads, email):
    return next((l for l in leads if l["email"].lower() == email.lower()), None)


def cmd_add(args):
    leads = load()
    if find(leads, args.email):
        print(f"lead exists: {args.email}")
        return 1
    leads.append({
        "email": args.email,
        "firstName": args.first or "",
        "tags": [args.tag] if args.tag else [],
        "step": 0,                      # next email index to send (0-6)
        "lastSentAt": None,             # ISO timestamp of last email sent
        "createdAt": now_iso(),
        "status": "active",
    })
    save(leads)
    print(f"added {args.email} (step 0, tags={leads[-1]['tags']})")
    return 0


def cmd_tag(args):
    leads = load()
    lead = find(leads, args.email)
    if not lead:
        print(f"lead not found: {args.email}")
        return 1
    if args.tag and args.tag not in lead["tags"]:
        lead["tags"].append(args.tag)
        save(leads)
    print(f"{args.email} tags={lead['tags']}")
    return 0


def cmd_list(args):
    leads = load()
    if args.tag:
        leads = [l for l in leads if args.tag in l["tags"]]
    if not leads:
        print("no leads")
        return 0
    for l in leads:
        print(f"{l['email']} | {l.get('firstName','')} | step {l['step']} | tags={l['tags']} | last={l.get('lastSentAt')}")
    print(f"\ntotal: {len(leads)}")
    return 0


def cmd_due(args):
    """Leads whose next email is due today (step < 7, status active)."""
    leads = load()
    now = datetime.now(timezone.utc)
    due = []
    for l in leads:
        if l["status"] != "active" or l["step"] >= 7:
            continue
        if l["step"] == 0 or l.get("lastSentAt") is None:
            due.append(l)
            continue
        last = datetime.fromisoformat(l["lastSentAt"])
        delay = SEQUENCE_DELAY_DAYS[l["step"]]
        if (now - last).days >= delay:
            due.append(l)
    for l in due:
        print(f"{l['email']} | {l.get('firstName','')} | next step {l['step']}")
    print(f"\ndue: {len(due)}")
    return 0


def cmd_advance(args):
    leads = load()
    lead = find(leads, args.email)
    if not lead:
        print(f"lead not found: {args.email}")
        return 1
    lead["step"] = args.step
    lead["lastSentAt"] = now_iso()
    save(leads)
    print(f"{args.email} -> step {args.step}")
    return 0


def cmd_stats(args):
    leads = load()
    active = sum(1 for l in leads if l["status"] == "active")
    done = sum(1 for l in leads if l["step"] >= 7)
    tags = {}
    for l in leads:
        for t in l["tags"]:
            tags[t] = tags.get(t, 0) + 1
    print(f"total={len(leads)} active={active} completed={done}")
    print("tags:", tags if tags else "none")
    return 0


def main():
    p = argparse.ArgumentParser(description="Local lead store (GC replacement)")
    sub = p.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("add")
    pa.add_argument("--email", required=True)
    pa.add_argument("--first", default="")
    pa.add_argument("--tag", default="")
    pa.set_defaults(fn=cmd_add)

    pt = sub.add_parser("tag")
    pt.add_argument("--email", required=True)
    pt.add_argument("--tag", required=True)
    pt.set_defaults(fn=cmd_tag)

    pl = sub.add_parser("list")
    pl.add_argument("--tag", default="")
    pl.set_defaults(fn=cmd_list)

    pd = sub.add_parser("due")
    pd.set_defaults(fn=cmd_due)

    pv = sub.add_parser("advance")
    pv.add_argument("--email", required=True)
    pv.add_argument("--step", type=int, required=True)
    pv.set_defaults(fn=cmd_advance)

    ps = sub.add_parser("stats")
    ps.set_defaults(fn=cmd_stats)

    args = p.parse_args()
    sys.exit(args.fn(args))


if __name__ == "__main__":
    main()
