#!/usr/bin/env python3
"""
Sendiio client for the Affiliate Offer Engine.

Sendiio is the recommended email sender: its sequences fire AUTOMATICALLY
when a subscriber joins a list, so the 7-email campaign needs no cron.

Credentials (stored in workspace/credentials/):
  sendiio-key.txt    -> API token
  sendiio-secret.txt -> API secret

Usage:
  python3 sendiio_client.py check              # validate credentials
  python3 sendiio_client.py lists              # list email lists
  python3 sendiio_client.py subscribe --list-id <encrypted_id> --email a@b.com [--first Jane] [--tag int-product]
  python3 sendiio_client.py webhooks           # list webhook subscriptions
  python3 sendiio_client.py webhook-add --url https://... --events email_added,clicked
  python3 sendiio_client.py webhook-del --id <webhook_id>
  python3 sendiio_client.py stats --seq <sequence_id> [--from 2026-08-01] [--to 2026-08-19]
  python3 sendiio_client.py fields --lists <encrypted_id[,encrypted_id...]>
  python3 sendiio_client.py forms              # list all forms
  python3 sendiio_client.py form-get --id <form_id>
  python3 sendiio_client.py form-edit --id <form_id> --name X --list-id <encrypted_id> --ok-url https://... --dup-url https://...
  python3 sendiio_client.py form-del --id <form_id>
  python3 sendiio_client.py unsubscribe --list-id <encrypted_id> --email a@b.com
  python3 sendiio_client.py list-get --id <encrypted_id>
  python3 sendiio_client.py list-fields --id <encrypted_id>
  python3 sendiio_client.py list-values --id <encrypted_id>
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.parse

BASE = "https://sendiio.com/api/v1"
CRED_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "..", "credentials")
# resolve: skills/affiliate-offer-engine/scripts -> workspace/credentials
CRED_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def load_creds():
    tok_path = os.path.join(CRED_DIR, "credentials", "sendiio-key.txt")
    sec_path = os.path.join(CRED_DIR, "credentials", "sendiio-secret.txt")
    if not (os.path.exists(tok_path) and os.path.exists(sec_path)):
        print("missing credentials: workspace/credentials/sendiio-key.txt + sendiio-secret.txt")
        sys.exit(1)
    token = open(tok_path).read().strip()
    secret = open(sec_path).read().strip()
    return token, secret


def api(method, path, token, secret, data=None):
    url = BASE + path
    headers = {"token": token, "secret": secret}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raw = e.read().decode()[:300]
        if raw.startswith("{"):
            return json.loads(raw)
        return {"error": 1, "msg": f"HTTP {e.code}: {raw}"}


def cmd_check(args):
    token, secret = load_creds()
    r = api("POST", "/auth/check", token, secret, {"token": token, "secret": secret})
    if r.get("error") == 0:
        print(f"OK — account user_id {r['data']['user_id']}")
        return 0
    print("FAILED:", r.get("msg") or r.get("errors"))
    return 1


def cmd_lists(args):
    token, secret = load_creds()
    r = api("GET", "/lists/email", token, secret)
    if r.get("error") != 0:
        print("error:", r.get("msg") or r.get("errors"))
        return 1
    lists = r.get("data", {}).get("lists", [])
    if not lists:
        print("no email lists. Create one at sendiio.com -> Email -> Lists -> Add List")
        return 0
    for l in lists:
        print(f"{l['encrypted_id']}  {l['name']}  (sender: {l.get('sender_name')})")
    return 0


def cmd_subscribe(args):
    token, secret = load_creds()
    data = {"email_list_id": args.list_id, "email": args.email}
    if args.first:
        data["first_name"] = args.first
    if args.last:
        data["last_name"] = args.last
    if args.tag:
        data["tag"] = args.tag
    # subscribe endpoint is PUBLIC (no auth headers needed), but sending them is harmless
    r = api("POST", "/lists/subscribe/json", token, secret, data)
    print(json.dumps(r, indent=2)[:500])
    return 0 if r.get("error") == 0 else 1


def cmd_webhooks(args):
    token, secret = load_creds()
    r = api("GET", "/webhook/get", token, secret)
    print(json.dumps(r, indent=2)[:800])
    return 0 if r.get("error") == 0 else 1


def cmd_webhook_add(args):
    token, secret = load_creds()
    data = {"url": args.url}
    for e in args.events.split(","):
        e = e.strip()
        if e in ("email_added", "opened", "clicked", "unsubscribed"):
            data[e] = 1
    r = api("POST", "/webhook/add", token, secret, data)
    print(json.dumps(r, indent=2)[:500])
    return 0 if r.get("error") == 0 else 1


def cmd_webhook_del(args):
    token, secret = load_creds()
    r = api("GET", f"/webhook/delete/{args.id}", token, secret)
    print(json.dumps(r, indent=2)[:500])
    return 0 if r.get("error") == 0 else 1


def cmd_stats(args):
    token, secret = load_creds()
    path = f"/sequences/{args.seq}/stats"
    if args.frm or args.to:
        path += f"/{args.frm or ''}/{args.to or ''}"
    r = api("GET", path, token, secret)
    if r.get("error") != 0:
        print("error:", r.get("msg") or r.get("errors"))
        return 1
    s = r.get("data", {}).get("sequence_stats", {})
    print("Sequence stats:")
    for k, v in s.items():
        print(f"  {k}: {v}")
    tpl = r.get("data", {}).get("sequence_templates_stats", {})
    if tpl:
        print("Per-email stats:")
        for idx, t in tpl.items():
            print(f"  email {idx}: sent={t.get('sent')} opened={t.get('opened')} clicked={t.get('clicked')} bounced={t.get('bounced')} unsub={t.get('unsub')}")
    return 0


def cmd_fields(args):
    token, secret = load_creds()
    r = api("POST", "/fields", token, secret, {"lists": args.lists})
    print(json.dumps(r, indent=2)[:600])
    return 0 if r.get("error") == 0 else 1


def cmd_forms(args):
    token, secret = load_creds()
    r = api("GET", "/forms", token, secret)
    if r.get("error") != 0:
        print("error:", r.get("msg") or r.get("errors"))
        return 1
    forms = r.get("data", {}).get("forms", [])
    if not forms:
        print("no forms")
        return 0
    for f in forms:
        print(f"{f['id']}  {f['name']}  list_id={f['list_id']} views={f['views']}")
    return 0


def cmd_form_get(args):
    token, secret = load_creds()
    r = api("GET", f"/forms/{args.id}", token, secret)
    print(json.dumps(r, indent=2)[:800])
    return 0 if r.get("error") == 0 else 1


def cmd_form_edit(args):
    token, secret = load_creds()
    data = {"name": args.name, "email_list_id": args.list_id}
    if args.ok_url:
        data["successfully_subscribed_url"] = args.ok_url
    if args.dup_url:
        data["already_subscribed_url"] = args.dup_url
    r = api("POST", f"/forms/{args.id}/edit", token, secret, data)
    print(json.dumps(r, indent=2)[:400])
    return 0 if r.get("error") == 0 else 1


def cmd_form_del(args):
    token, secret = load_creds()
    r = api("GET", f"/forms/{args.id}/delete", token, secret)
    print(json.dumps(r, indent=2)[:400])
    return 0 if r.get("error") == 0 else 1


def cmd_unsubscribe(args):
    token, secret = load_creds()
    r = api("POST", f"/lists/{args.list_id}/unsubscribe", token, secret, {"email": args.email})
    print(json.dumps(r, indent=2)[:400])
    return 0 if r.get("error") == 0 else 1


def cmd_list_get(args):
    token, secret = load_creds()
    r = api("GET", f"/lists/email/{args.id}", token, secret)
    print(json.dumps(r, indent=2)[:600])
    return 0 if r.get("error") == 0 else 1


def cmd_list_fields(args):
    token, secret = load_creds()
    r = api("GET", f"/lists/email/fields/{args.id}", token, secret)
    print(json.dumps(r, indent=2)[:600])
    return 0 if r.get("error") == 0 else 1


def cmd_list_values(args):
    token, secret = load_creds()
    r = api("GET", f"/lists/email/fields-values/{args.id}", token, secret)
    print(json.dumps(r, indent=2)[:800])
    return 0 if r.get("error") == 0 else 1


def main():
    p = argparse.ArgumentParser(description="Sendiio client (AOE sender)")
    sub = p.add_subparsers(dest="cmd", required=True)

    pc = sub.add_parser("check")
    pc.set_defaults(fn=cmd_check)

    pl = sub.add_parser("lists")
    pl.set_defaults(fn=cmd_lists)

    ps = sub.add_parser("subscribe")
    ps.add_argument("--list-id", required=True)
    ps.add_argument("--email", required=True)
    ps.add_argument("--first", default="")
    ps.add_argument("--last", default="")
    ps.add_argument("--tag", default="")
    ps.set_defaults(fn=cmd_subscribe)

    pw = sub.add_parser("webhooks")
    pw.set_defaults(fn=cmd_webhooks)

    pwa = sub.add_parser("webhook-add")
    pwa.add_argument("--url", required=True)
    pwa.add_argument("--events", default="email_added")
    pwa.set_defaults(fn=cmd_webhook_add)

    pwd = sub.add_parser("webhook-del")
    pwd.add_argument("--id", required=True)
    pwd.set_defaults(fn=cmd_webhook_del)

    pst = sub.add_parser("stats")
    pst.add_argument("--seq", required=True)
    pst.add_argument("--from", dest="frm", default="")
    pst.add_argument("--to", default="")
    pst.set_defaults(fn=cmd_stats)

    pf = sub.add_parser("fields")
    pf.add_argument("--lists", required=True)
    pf.set_defaults(fn=cmd_fields)

    pfo = sub.add_parser("forms")
    pfo.set_defaults(fn=cmd_forms)

    pfg = sub.add_parser("form-get")
    pfg.add_argument("--id", required=True)
    pfg.set_defaults(fn=cmd_form_get)

    pfe = sub.add_parser("form-edit")
    pfe.add_argument("--id", required=True)
    pfe.add_argument("--name", required=True)
    pfe.add_argument("--list-id", required=True)
    pfe.add_argument("--ok-url", default="")
    pfe.add_argument("--dup-url", default="")
    pfe.set_defaults(fn=cmd_form_edit)

    pfd = sub.add_parser("form-del")
    pfd.add_argument("--id", required=True)
    pfd.set_defaults(fn=cmd_form_del)

    pu = sub.add_parser("unsubscribe")
    pu.add_argument("--list-id", required=True)
    pu.add_argument("--email", required=True)
    pu.set_defaults(fn=cmd_unsubscribe)

    plg = sub.add_parser("list-get")
    plg.add_argument("--id", required=True)
    plg.set_defaults(fn=cmd_list_get)

    plf = sub.add_parser("list-fields")
    plf.add_argument("--id", required=True)
    plf.set_defaults(fn=cmd_list_fields)

    plv = sub.add_parser("list-values")
    plv.add_argument("--id", required=True)
    plv.set_defaults(fn=cmd_list_values)

    args = p.parse_args()
    sys.exit(args.fn(args))


if __name__ == "__main__":
    main()
