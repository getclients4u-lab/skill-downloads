#!/usr/bin/env python3
"""
Muncheye Launch Calendar Scraper
Fetches upcoming product launches from Muncheye.com
"""

import sys
import urllib.request
import re
from datetime import datetime, timedelta
from html import unescape
import json

def scrape_launches(days=7, filter_type='all'):
    """
    Scrape Muncheye for launches
    
    Args:
        days (int): Number of days to look ahead
        filter_type (str): 'all', 'big', or 'normal'
    
    Returns:
        list: Launch data
    """
    try:
        req = urllib.request.Request('https://muncheye.com', headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        
        # Pattern to match launch items
        pattern = r"<div class='date'><span class='day'>(\d+)</span><span class='month'>&nbsp;(\w+)</span></div><div class='item_info'><a href='([^']+)'[^>]*>([^<]+)</a><span class='item_details'>&nbsp;\$?([0-9.]+) at (\d+)%"
        
        matches = re.findall(pattern, html)
        
        today = datetime.now()
        target_date = today + timedelta(days=days)
        
        launches = {}
        
        for day, month, url, title, price, commission in matches:
            try:
                launch_date = datetime.strptime(f"{day} {month} 2026", "%d %b %Y")
                
                if today <= launch_date <= target_date:
                    clean_title = unescape(title).strip()
                    price_float = float(price)
                    
                    # Create unique key
                    key = (launch_date, clean_title)
                    
                    # Determine if it's a "big" launch (price >= $37)
                    is_big = price_float >= 37
                    
                    if key not in launches:
                        launches[key] = {
                            'date': launch_date.strftime('%Y-%m-%d'),
                            'date_display': launch_date.strftime('%b %d'),
                            'title': clean_title,
                            'price': price_float,
                            'commission': int(commission),
                            'url': f"https://muncheye.com{url}",
                            'is_big': is_big
                        }
            except Exception as e:
                continue
        
        # Sort by date
        sorted_launches = sorted(launches.values(), key=lambda x: x['date'])
        
        # Filter by type
        if filter_type == 'big':
            sorted_launches = [l for l in sorted_launches if l['is_big']]
        elif filter_type == 'normal':
            sorted_launches = [l for l in sorted_launches if not l['is_big']]
        
        return sorted_launches
        
    except Exception as e:
        print(f"Error scraping Muncheye: {str(e)}", file=sys.stderr)
        return []


def display_launches(launches, format='table'):
    """Display launches in requested format"""
    
    if not launches:
        print("No launches found in the specified timeframe")
        return
    
    if format == 'json':
        print(json.dumps(launches, indent=2))
        return
    
    # Table format
    print("\n" + "="*80)
    print(f"{'#':<4} {'Date':<8} {'Product':<45} {'Price':<8} {'Comm'}")
    print("="*80)
    
    for i, launch in enumerate(launches, 1):
        title_short = launch['title'][:43] + '..' if len(launch['title']) > 45 else launch['title']
        print(f"{i:<4} {launch['date_display']:<8} {title_short:<45} ${launch['price']:<7.0f} {launch['commission']}%")
    
    print("="*80)
    print(f"Total: {len(launches)} launches\n")


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Scrape Muncheye launch calendar')
    parser.add_argument('--days', type=int, default=7, help='Days to look ahead (default: 7)')
    parser.add_argument('--filter', choices=['all', 'big', 'normal'], default='all', 
                        help='Filter by launch type')
    parser.add_argument('--format', choices=['table', 'json'], default='table',
                        help='Output format')
    
    args = parser.parse_args()
    
    launches = scrape_launches(days=args.days, filter_type=args.filter)
    display_launches(launches, format=args.format)
