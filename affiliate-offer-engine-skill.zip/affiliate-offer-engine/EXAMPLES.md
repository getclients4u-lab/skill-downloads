# Complete Examples - Copy/Paste These Exactly

## Example 1: Full Campaign Build (ProfitPilot AI)

This is a complete, working example. Copy these commands exactly.

### Step 1: Find the Launch

```bash
python3 ~/.openclaw/workspace/skills/affiliate-offer-engine/scripts/muncheye_scraper.py --days 7 --filter big --format json
```

**Expected Output:**
```json
[
  {
    "date": "2026-05-14",
    "date_display": "May 14",
    "title": "Sameer Dhawan: ProfitPilot AI",
    "price": 67.0,
    "commission": 50,
    "url": "https://muncheye.com/profitpilot-ai-jvzoo-may-14-67-50-commissions",
    "is_big": true
  }
]
```

### Step 2: Fetch JV Page

```bash
curl -s "https://muncheye.com/profitpilot-ai-jvzoo-may-14-67-50-commissions" | grep -oP 'https?://[^"]+jv[^"]+vercel\.app' | head -1
```

**Expected Output:**
```
https://profitpilot-jv.vercel.app
```

### Step 3: Get Sales Page URL

```bash
curl -s "https://profitpilot-jv.vercel.app" | grep -oP 'Sales Page.*?href="([^"]+)"' | grep -oP 'https?://[^"]+' | head -1
```

**Expected Output:**
```
https://profitpilot-jvzoo.vercel.app
```

### Step 4: Extract Design System

```bash
curl -s "https://profitpilot-jvzoo.vercel.app" | grep -E "color|--" | head -20
```

**Expected Colors:**
```
--navy:#0B1120
--electric:#4F8EFF
--teal:#00D4B4
--green:#22C55E
--amber:#F59E0B
```

**Save to file:**
```bash
cat > ~/.openclaw/workspace/profitpilot-campaign/design-system.md << 'EOF'
# ProfitPilot AI Design System

## Colors
- Primary: #00D4B4 (teal)
- Secondary: #4F8EFF (electric blue)
- Background: #0B1120 (navy)
- Accent: #22C55E (green), #F59E0B (amber)

## Fonts
- Font: 'Segoe UI', Arial, sans-serif

## Effects
- Gradient backgrounds
- Box shadows on CTAs
- Hover effects
EOF
```

### Step 5: Create the PopLink (no API — Vercel redirect)

```bash
cd /path/to/campaign
python3 scripts/make_poplinks.py add --slug profitpilot --url "https://affiliate.example.com/?ref=you"
python3 scripts/make_poplinks.py generate --out vercel.json
```

**Expected Output:**
```
poplink: /profitpilot -> https://affiliate.example.com/?ref=you
wrote vercel.json with 1 redirects
```

Deploy the campaign to Vercel — `https://<campaign-domain>/profitpilot` now redirects to the affiliate link. No PageSprout, no API key.

### Step 6: Add the Interest Tag (Sendiio custom field)

With Sendiio, the tag is just a custom field passed at subscribe time:

```bash
python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email lead@example.com --first Lead --tag int-profitpilot
```

**Expected Output:**
```
{"error": 0, "msg": "You were successfully subscribed", ...}
```

Local fallback (no Sendiio):
```bash
python3 scripts/lead_store.py add --email lead@example.com --first Lead --tag int-profitpilot
```

### Step 7 (Sendiio path): Create List + Sequence in Dashboard (one-time)

1. sendiio.com → Email → Lists → Add List ("Affiliate Campaigns")
2. Email → Sequences → create 7-email flow (email 1 immediate, then 2-day gaps)
3. Attach the sequence to the list so it fires on subscribe
4. Get the encrypted_id: `python3 scripts/sendiio_client.py lists`

### Step 8 (Sendiio path): Wire the Opt-In Form (replaces tag→workflow link)

The pre-sell page's email form posts directly to the public subscribe endpoint:
```bash
python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email [email] --first [name] --tag int-profitpilot
```
The sequence auto-fires — no cron needed.

### Step 9 (Sendiio path): Register Lead Alerts + Test

```bash
python3 scripts/sendiio_client.py webhook-add --url https://your-endpoint/hook --events email_added
python3 scripts/sendiio_client.py subscribe --list-id [encrypted_id] --email test@example.com --first Test
python3 scripts/sendiio_client.py stats --seq [sequence_id]
```

**Expected Output:** email 1 arrives within minutes; stats show 1 sent.

---

## Example 1-alt: Local Cron Fallback (no Sendiio)

### Step 6: Add the Interest Tag (local lead store)

```bash
python3 scripts/lead_store.py add --email lead@example.com --first Lead --tag int-profitpilot
```

**Expected Output:**
```
added lead@example.com (step 0, tags=['int-profitpilot'])
```

### Step 7: Save the 7 Sequence Emails (replaces SMTP + flows)

Save as `campaign/emails/email-1.html` … `email-7.html`:

```html
<!-- email-1.html -->
<title>The 'I don't have time' problem</title>
<body><p>Hi {{firstName}},</p><p>...problem email...</p></body>
```

### Step 8: Create the Daily Cron (replaces workflow timers)

Create an OpenClaw cron job, daily at 09:00:
1. `python3 scripts/lead_store.py due --tag int-profitpilot`
2. For each due lead: send `email-{step+1}.html` via AgentMail (`text` param, not `body`)
3. `python3 scripts/lead_store.py advance --email [email] --step [step+1]`

### Step 9: Wire the Opt-In Form (replaces tag→workflow link)

The pre-sell page's email form calls a Vercel function that runs:

```bash
python3 scripts/lead_store.py add --email [email] --first [name] --tag int-profitpilot
```

### Step 10: Test the Sequence

```bash
python3 scripts/lead_store.py add --email test@example.com --first Test --tag int-profitpilot
python3 scripts/lead_store.py due --tag int-profitpilot
python3 scripts/lead_store.py advance --email test@example.com --step 1
python3 scripts/lead_store.py list --tag int-profitpilot
```

**Expected Output:**
```
due: 1
test@example.com -> step 1
test@example.com | Test | step 1 | tags=['int-profitpilot']
```

## Example 2: Quick Sales Page Deployment

### Create Sales Page from Master Template

```bash
# Create directory
mkdir -p ~/.openclaw/workspace/profitpilot-campaign/sales-page

# Fetch master template
curl -s "https://sales-page-template-wine.vercel.app" > /tmp/master-sales.html

# Replace placeholders (product-specific)
cat /tmp/master-sales.html | \
  sed 's/#926CD6/#00D4B4/g' | \
  sed 's/#7B5CC4/#4F8EFF/g' | \
  sed 's/Vizard AI/ProfitPilot AI/g' | \
  sed 's/content creation/lead generation/g' \
  > ~/.openclaw/workspace/profitpilot-campaign/sales-page/index.html

# Deploy to Vercel
cd ~/.openclaw/workspace/profitpilot-campaign/sales-page
vercel --prod --yes --token $(cat ~/.openclaw/workspace/credentials/vercel-token.txt)
```

**Expected Output:**
```
✅ Production: https://sales-page-xyz.vercel.app
```

---

## Example 3: Create Bonus Delivery Page

```bash
# Create directory
mkdir -p ~/.openclaw/workspace/profitpilot-campaign/bonuses/delivery

# Fetch master template
curl -s "https://delivery-template-delta.vercel.app" > /tmp/master-delivery.html

# Replace placeholders
cat /tmp/master-delivery.html | \
  sed 's/#926CD6/#00D4B4/g' | \
  sed 's/Vizard AI/ProfitPilot AI/g' | \
  sed 's/content creation/lead generation/g' \
  > ~/.openclaw/workspace/profitpilot-campaign/bonuses/delivery/index.html

# Deploy
cd ~/.openclaw/workspace/profitpilot-campaign/bonuses/delivery
vercel --prod --yes --token $(cat ~/.openclaw/workspace/credentials/vercel-token.txt)
```

---

## Example 4: Email Sequence Template

Save this as a starting point for all campaigns:

```markdown
# Email 1 - Problem (Day 0)

**Subject:** The "[specific problem]" problem

Hey [firstname],

You're spending [X hours] per week on [painful task].

But here's the thing: it's not just about time.

It's about what you're NOT doing while you're stuck [doing painful task]:
- Not [desired activity 1]
- Not [desired activity 2]
- Not [desired activity 3]
- Not [desired activity 4]

The [problem] trap is real.

Tomorrow I'll show you what happens when AI does 70% of [task] for you.

[Your Name]

---

# Email 2 - Solution (Day 2)

**Subject:** Meet your new AI [solution type]

[firstname],

What if you could:
- [Benefit 1]
- [Benefit 2]
- [Benefit 3]

That's what [Product Name] does.

**Here's how it works:**
1. [Step 1]
2. [Step 2]
3. [Step 3]
4. [Step 4]
5. [Step 5]

**70% of the work done automatically.**

👉 Click here to try it: [POPLINK]

No credit card required. See for yourself.

[Your Name]

P.S. When you sign up, you get my [Bonus Name] ($XX value).
```

---

## Example 5: Verify Entire Campaign

Run this checklist command:

```bash
cat << 'EOF' > /tmp/campaign-check.sh
#!/bin/bash

echo "🔍 Campaign Verification Checklist"
echo "=================================="
echo ""

# Sendiio status
echo "📮 Sendiio:"
python3 scripts/sendiio_client.py check
python3 scripts/sendiio_client.py lists

echo ""
# Local store (fallback)
echo "📋 Lead Store (fallback only):"
python3 scripts/lead_store.py stats

echo "📋 PopLinks (Vercel redirects):"
python3 scripts/make_poplinks.py list

echo "📋 Webhooks:"
python3 scripts/sendiio_client.py webhooks

echo ""
echo "=================================="
echo "✅ = Good to go"
echo "❌ = Missing (campaign won't work)"
EOF

chmod +x /tmp/campaign-check.sh
bash /tmp/campaign-check.sh
```

---

## Common Command Reference

### List all leads with a tag
```bash
python3 scripts/lead_store.py list --tag int-profitpilot
```

### See which leads are due their next email
```bash
python3 scripts/lead_store.py due
```

### Advance a lead after sending
```bash
python3 scripts/lead_store.py advance --email lead@example.com --step 2
```

### Add a PopLink + regenerate redirects
```bash
python3 scripts/make_poplinks.py add --slug profitpilot --url "https://affiliate.example.com/?ref=you"
python3 scripts/make_poplinks.py generate --out vercel.json
```data = json.load(sys.stdin)
for wf in data.get('data', []):
    if 'ProfitPilot' in wf.get('name', ''):
        print(f\"Workflow ID: {wf['_id']}\")
        print(f\"Name: {wf['name']}\")
"
```

### Test Vercel Token
```bash
curl -H "Authorization: Bearer $(cat ~/.openclaw/workspace/credentials/vercel-token.txt)" \
  https://api.vercel.com/v2/user
```

Should return your user info. If 401/403, token is invalid.

---

## Pro Tips for Other Bots

### 1. Always Verify the Cron
After creating the daily sequence cron, immediately verify:
```bash
openclaw cron list
```
If the job is missing, STOP and create it before continuing.

### 2. Always Verify the Send Pipeline
After adding a test lead, immediately verify:
```bash
python3 scripts/lead_store.py due --tag int-product
```
If the lead doesn't show as due, STOP and fix the tag wiring before continuing.

### 3. Advance Only After Successful Send
As soon as an email sends successfully, advance the lead:
```bash
python3 scripts/lead_store.py advance --email lead@example.com --step N+1
```
If the send fails, do NOT advance — the lead stays due and will retry.

### 4. Test Early, Test Often
Don't wait until the end to test. Add a test lead after each major step.

### 5. Use JSON Format for Parsing
When you need to extract data, use `--format json`:
```bash
python3 muncheye_scraper.py --format json | python3 -c "import sys, json; print(json.load(sys.stdin)[0]['url'])"
```

---

**Copy these examples exactly. They work. Don't improvise.**
